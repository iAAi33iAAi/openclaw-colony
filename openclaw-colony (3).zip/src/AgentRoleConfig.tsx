import React from "react";
import { AGENT_NAMES } from "./SevenAgentInterface";

interface AgentRoleConfigProps {
  roles: Record<string, string>;
  onRoleChange: (agent: string, role: string) => void;
  onClose: () => void;
}

const AVAILABLE_ROLES = [
  "Coordinator",
  "Data Processor",
  "Security Auditor",
  "Analyst",
  "Communicator",
  "Strategist",
  "Innovator"
];

export default function AgentRoleConfig({ roles, onRoleChange, onClose }: AgentRoleConfigProps) {
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-sm shadow-2xl">
        <h2 className="text-lg font-bold text-white mb-4">Configure Agent Roles</h2>
        <div className="space-y-3">
          {AGENT_NAMES.map(name => (
            <div key={name} className="flex items-center justify-between">
              <span className="text-slate-300 text-sm">{name}</span>
              <select 
                value={roles[name] || AVAILABLE_ROLES[0]}
                onChange={(e) => onRoleChange(name, e.target.value)}
                className="bg-slate-800 text-white text-xs p-1 rounded border border-slate-700"
              >
                {AVAILABLE_ROLES.map(role => (
                  <option key={role} value={role}>{role}</option>
                ))}
              </select>
            </div>
          ))}
        </div>
        <button onClick={onClose} className="mt-6 w-full py-2 bg-indigo-600 text-white rounded font-semibold hover:bg-indigo-700 text-sm">Done</button>
      </div>
    </div>
  );
}
