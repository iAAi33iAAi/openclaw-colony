import SevenAgentInterface from './SevenAgentInterface';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <SevenAgentInterface />
    </div>
  );
}
