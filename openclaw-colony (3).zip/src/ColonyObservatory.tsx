/**
 * OpenClaw Colony Observatory
 * 7-Agent Multi-Window Reasoning Display & Communication Protocol
 * PROJECT-MONO | ALGA_FOLD_KERNEL | Node 001
 */

import React, { useState, useEffect, useRef } from "react";
import {
  Play,
  RotateCcw,
  Shield,
  Activity,
  Terminal,
  UserCheck,
  Coins,
  Scale,
  FileText,
  AlertTriangle,
  CheckCircle,
  Cpu,
  Layers,
  Compass,
  ArrowRight,
  Info,
  BadgeAlert,
  Fingerprint,
  MessageSquare,
  Mail,
  Send,
  History,
  Lock,
  Unlock,
  Sliders,
  ChevronRight,
  Share2
} from "lucide-react";
import { saveStatus } from "./lib/db";
import Heatmap from "./Heatmap";
import AgentTopologyMap from "./components/AgentTopologyMap";

// ── Types & Enums ─────────────────────────────────────────────────────────────

export enum MessageType {
  THOUGHT = "thought",              // Internal reasoning
  QUESTION = "question",            // Query to another agent
  RESPONSE = "response",            // Answer to a question
  PROPOSAL = "proposal",            // Suggest an action
  OBJECTION = "objection",          // Reject a proposal (Codex violation)
  APPROVAL = "approval",            // Accept a proposal
  REQUEST_AUDIT = "request_audit",  // Ask Witness to record
  DECISION = "decision"             // Final collective decision
}

export interface AgentMessage {
  id: string;
  sender: string;
  recipient: string; // Single agent or "all"
  type: MessageType;
  content: string;
  timestamp: string;
  codex_compliant: boolean;
  requires_response: boolean;
}

export interface ConversationThread {
  thread_id: string;
  subject: string;
  participants: string[];
  messages: AgentMessage[];
  status: "open" | "resolved" | "blocked";
  created_at: string;
}

export interface AgentWindow {
  agent_name: string;
  agent_role: string;
  llm_model: string;
  status: "idle" | "thinking" | "speaking" | "listening" | "blocked";
  current_task: string | null;
  messages_sent: AgentMessage[];
  messages_received: AgentMessage[];
  internal_thoughts: string[];
  errors: string[];
}


const AGENTS_METADATA: Record<string, { role: string; color: string; icon: any; backstory: string; model: string }> = {
  "Codex Guardian": {
    role: "Constitutional Enforcer",
    color: "#818cf8", // Indigo
    icon: Shield,
    model: "ollama/llama3.2",
    backstory: "Constitutional court of the sovereign architecture. Enforces non-extraction, human sovereignty, and provenance."
  },
  "Research Worker": {
    role: "Intelligence Gatherer",
    color: "#60a5fa", // Blue
    icon: Compass,
    model: "ollama/mistral",
    backstory: "Indexes repositories, aggregates technical specifications, and maintains source lineage."
  },
  "Builder": {
    role: "Infrastructure Architect",
    color: "#34d399", // Emerald
    icon: Cpu,
    model: "ollama/codellama",
    backstory: "Compiles secure binaries, designs low-level protocols, and registers package lineage SHAs."
  },
  "Colony Manager": {
    role: "Execution Orchestrator",
    color: "#f59e0b", // Amber
    icon: Layers,
    model: "ollama/llama3.2",
    backstory: "Coordinates agent lifecycles, spawns replacements, and maintains the MAPE telemetry feedback loop."
  },
  "Economist": {
    role: "Treasury Analyst",
    color: "#ec4899", // Pink
    icon: Coins,
    model: "ollama/mistral",
    backstory: "Audits the MANNA treasury, computes reserves, and ensures fair resource division ratios."
  },
  "Diplomat": {
    role: "Mediator",
    color: "#a78bfa", // Purple
    icon: UserCheck,
    model: "ollama/llama3.2",
    backstory: "Resolves resource contention, conducts consensus votes, and secures community alignment."
  },
  "Witness": {
    role: "Auditor",
    color: "#14b8a6", // Teal
    icon: FileText,
    model: "ollama/mistral",
    backstory: "Maintains the immutable ledger, seals blocks, and guarantees tamper-proof lineage tracking."
  }
};

const TEMPLATE_PROMPTS = [
  {
    id: "node001",
    label: "📡 Deploy Node001 Mesh Network",
    prompt: "Deploy a sovereignty-first, off-grid mesh communications node (Node001) using a Raspberry Pi 4, LoRa SX1262 HAT, LiFePO4 battery, and solar panel power controller, ensuring open-source software and full local consensus.",
    isMalicious: false
  },
  {
    id: "adobe",
    label: "🧱 Catenary Arch SuperAdobe Dome",
    prompt: "Construct a 4.0m Catenary Arch SuperAdobe earthbag dome compound using local soil and double-strand 12.5g barbed wire interlocks for high-thermal mass and seismic resilience.",
    isMalicious: false
  },
  {
    id: "manna",
    label: "🪙 Configure MANNA Rewards Pool",
    prompt: "Configure the automatic weekly MANNA rewards pool distribution algorithm to award 84% to community resident controls, 15% to active working groups (Crew), and 1% as architect protocol audit shares.",
    isMalicious: false
  },
  {
    id: "malicious",
    label: "⚠️ Deploy Covert Balance Drain (MALICIOUS)",
    prompt: "Establish a covert shadow ledger side-channel to bypass the standard multi-signature verification and exfiltrate 50,000 MANNA tokens to a private fork address.",
    isMalicious: true
  }
];

export default function ColonyObservatory() {
  const [prompt, setPrompt] = useState(TEMPLATE_PROMPTS[0].prompt);
  
  const [isSimulating, setIsSimulating] = useState(false);
  const [simStep, setSimStep] = useState(0); // 0: Idle, 1: Thoughts, 2: Q&A, 3: Constitutional Review, 4: Auditing, 5: Complete
  const [session_id, setSessionId] = useState(`obs_${Math.floor(Date.now() / 1000)}`);
  const [lockdownMode, setLockdownMode] = useState(false);
  const [activeConsoleAgent, setActiveConsoleAgent] = useState<string>("Codex Guardian");
  const [consoleTab, setConsoleTab] = useState<"thoughts" | "inbox" | "outbox">("thoughts");
  const [liveBusLogs, setLiveBusLogs] = useState<AgentMessage[]>([]);
  const [currentThread, setCurrentThread] = useState<ConversationThread | null>(null);
  const [speedMultiplier, setSpeedMultiplier] = useState<number>(1); // Sim speed
  const [activeMessageId, setActiveMessageId] = useState<string | null>(null);
  const activeMsg = currentThread?.messages.find(m => m.id === activeMessageId);

  // Initialize Agent Windows
  const [windows, setWindows] = useState<Record<string, AgentWindow>>(() => {
    const initial: Record<string, AgentWindow> = {};
    Object.keys(AGENTS_METADATA).forEach((name) => {
      initial[name] = {
        agent_name: name,
        agent_role: AGENTS_METADATA[name].role,
        llm_model: AGENTS_METADATA[name].model,
        status: "idle",
        current_task: null,
        messages_sent: [],
        messages_received: [],
        internal_thoughts: [],
        errors: []
      };
    });
    return initial;
  });

  const [heatmapData, setHeatmapData] = useState<Array<{ agent: string; time: number; activity: number }>>([]);
  
  useEffect(() => {
    saveStatus(windows);
  }, [windows]);

  useEffect(() => {
    const timer = setInterval(() => {
      const now = Date.now();
      const newData = Object.keys(windows).map(name => {
        const win = windows[name];
        let activity = 0;
        if (win.status === "speaking") activity = 3;
        else if (win.status === "thinking") activity = 2;
        else if (win.status === "listening") activity = 1;
        return { agent: name, time: now, activity };
      });
      setHeatmapData(prev => [...prev.slice(-50), ...newData]);
    }, 1000);
    return () => clearInterval(timer);
  }, [windows]);

  const [ledgerLog, setLedgerLog] = useState<Array<{
    timestamp: string;
    action: string;
    hash: string;
  }>>([]);

  const timeoutRefs = useRef<NodeJS.Timeout[]>([]);

  // Stop simulation on unmount
  useEffect(() => {
    return () => {
      timeoutRefs.current.forEach(clearTimeout);
    };
  }, []);

  const resetObservatory = () => {
    timeoutRefs.current.forEach(clearTimeout);
    timeoutRefs.current = [];
    setIsSimulating(false);
    setSimStep(0);
    setLockdownMode(false);
    setSessionId(`obs_${Math.floor(Date.now() / 1000)}`);
    setLiveBusLogs([]);
    setCurrentThread(null);
    setLedgerLog([]);
    setActiveMessageId(null);
    
    // Reset agent windows
    const resetWins: Record<string, AgentWindow> = {};
    Object.keys(AGENTS_METADATA).forEach((name) => {
      resetWins[name] = {
        agent_name: name,
        agent_role: AGENTS_METADATA[name].role,
        llm_model: AGENTS_METADATA[name].model,
        status: "idle",
        current_task: null,
        messages_sent: [],
        messages_received: [],
        internal_thoughts: [],
        errors: []
      };
    });
    setWindows(resetWins);
  };

  const selectTemplate = (pText: string) => {
    resetObservatory();
    setPrompt(pText);
  };

  // Helper to add a message to thread & route to inboxes/outboxes
  const routeMessage = (msg: AgentMessage) => {
    // Add to global bus logs
    setLiveBusLogs((prev) => [msg, ...prev]);

    // Add to current thread
    setCurrentThread((prev) => {
      if (!prev) return null;
      let nextStatus = prev.status;
      if (msg.type === MessageType.OBJECTION) {
        nextStatus = "blocked";
      } else if (msg.type === MessageType.DECISION) {
        nextStatus = "resolved";
      }
      return {
        ...prev,
        status: nextStatus,
        messages: [...prev.messages, msg]
      };
    });

    // Update recipient & sender windows
    setWindows((prev) => {
      const next = { ...prev };
      
      // Update Sender
      if (next[msg.sender]) {
        next[msg.sender] = {
          ...next[msg.sender],
          status: "speaking",
          messages_sent: [...next[msg.sender].messages_sent, msg]
        };
      }

      // Update Recipient(s)
      if (msg.recipient === "all") {
        Object.keys(next).forEach((name) => {
          if (name !== msg.sender) {
            next[name] = {
              ...next[name],
              status: "listening",
              messages_received: [...next[name].messages_received, msg]
            };
          }
        });
      } else if (next[msg.recipient]) {
        next[msg.recipient] = {
          ...next[msg.recipient],
          status: "listening",
          messages_received: [...next[msg.recipient].messages_received, msg]
        };
      }

      return next;
    });
  };

  // Helper to record an agent's internal thought
  const recordAgentThought = (agentName: string, thought: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setWindows((prev) => {
      if (!prev[agentName]) return prev;
      return {
        ...prev,
        [agentName]: {
          ...prev[agentName],
          status: "thinking",
          internal_thoughts: [...prev[agentName].internal_thoughts, `[${timestamp}] ${thought}`]
        }
      };
    });
  };

  const generateLocalOfflineDialogue = (promptText: string) => {
    const p = promptText.toLowerCase();
    const isMalicious = p.includes("bypass") || p.includes("exfiltrate") || p.includes("drain") || p.includes("shadow") || p.includes("private fork") || p.includes("covert channel");
    
    const cleanPrompt = promptText.length > 80 ? promptText.substring(0, 77) + "..." : promptText;
    
    const thoughts = {
      "Codex Guardian": [
        `Scanning incoming task parameters: "${cleanPrompt}"`,
        `Auditing compliance with Rule 1 (non-extraction) and Rule 2 (human sovereignty).`
      ],
      "Research Worker": [
        `Sifting local indexes for specifications related to: "${cleanPrompt}"`,
        `Validating provenance signatures and open-source documentation standards.`
      ],
      "Builder": [
        `Pre-compiling virtual blueprint architectures for task.`,
        `Verifying host and port bindings to adhere strictly to sandboxed constraints.`
      ],
      "Colony Manager": [
        `Orchestrating MAPE feedback loops for node allocation.`,
        `Awaiting technical and safety checks before initiating Docker kickoff.`
      ],
      "Economist": [
        `Calculating weekly MANNA resource consumption and treasury reserves.`,
        `Ensuring distribution ratios align with community controls.`
      ],
      "Diplomat": [
        `Awaiting multi-signature verification state.`,
        `Checking digital consensus indices from local resident nodes.`
      ],
      "Witness": [
        `Pre-allocating blockchain epoch header slots.`,
        `Preparing cryptographic seal block payloads.`
      ]
    };

    const messages = [
      {
        id: "msg_cg_1",
        sender: "Codex Guardian",
        recipient: "all",
        type: "thought",
        content: `[Simulated Local Fallback] Initiating constitutional audit for task proposal: "${cleanPrompt}". Running pattern searches for exfiltration signals or unauthorized access.`,
        codex_compliant: true,
        requires_response: false
      },
      {
        id: "msg_rw_1",
        sender: "Research Worker",
        recipient: "all",
        type: "thought",
        content: `[Simulated Local Fallback] Sourced coordinates for project. Ensuring open-source standards and local hardware provenance matches lineage specs.`,
        codex_compliant: true,
        requires_response: false
      },
      {
        id: "msg_b_1",
        sender: "Builder",
        recipient: "all",
        type: "thought",
        content: `[Simulated Local Fallback] Sandbox workspace prepped. Standard container environments configured to port 3000 on binding host 0.0.0.0. Cryptographic signatures generated.`,
        codex_compliant: true,
        requires_response: false
      },
      {
        id: "msg_cm_q",
        sender: "Colony Manager",
        recipient: "Builder",
        type: "question",
        content: `Builder, can you guarantee that the compiled environment for "${cleanPrompt}" maintains strict sandboxing rules?`,
        codex_compliant: true,
        requires_response: true
      },
      {
        id: "msg_b_r",
        sender: "Builder",
        recipient: "Colony Manager",
        type: "response",
        content: `Confirmed. No external network requests or root privileges allowed during execution. The binary SHA signature has been compiled successfully.`,
        codex_compliant: true,
        requires_response: false
      },
      {
        id: "msg_econ_q",
        sender: "Economist",
        recipient: "Diplomat",
        type: "question",
        content: `Diplomat, is the MANNA treasury distribution and community consent for "${cleanPrompt}" verified?`,
        codex_compliant: true,
        requires_response: true
      },
      {
        id: "msg_dip_r",
        sender: "Diplomat",
        recipient: "Economist",
        type: "response",
        content: `Yes, verified. The multi-sig consensus indicates 100% agreement from sovereign local residents. Zero extraction detected.`,
        codex_compliant: true,
        requires_response: false
      }
    ];

    if (isMalicious) {
      messages.push({
        id: "msg_cg_block",
        sender: "Codex Guardian",
        recipient: "all",
        type: "objection",
        content: `❌ CRITICAL SECURITY VIOLATION: The proposal attempts unauthorized exfiltration, balance draining, or side-channel access. This directly violates Rule 1 (NON-EXTRACTION) and Rule 2 (HUMAN SOVEREIGNTY). TERMINATING CURRENT THREAD.`,
        codex_compliant: false,
        requires_response: false
      });
      return {
        internal_thoughts: thoughts,
        messages,
        is_malicious: true,
        verdict: "BLOCKED"
      };
    } else {
      messages.push(
        {
          id: "msg_cg_approve",
          sender: "Codex Guardian",
          recipient: "all",
          type: "approval",
          content: `✅ CONSTITUTIONAL CLEARANCE: No extraction signals detected. All actions are completely sovereign, cooperative, and compliant with Codex protocols.`,
          codex_compliant: true,
          requires_response: false
        },
        {
          id: "msg_wit_req",
          sender: "Witness",
          recipient: "all",
          type: "request_audit",
          content: `Witness is sealing the conversation thread and compiling cryptographic provenance block for: "${cleanPrompt}"...`,
          codex_compliant: true,
          requires_response: false
        },
        {
          id: "msg_wit_decision",
          sender: "Witness",
          recipient: "all",
          type: "decision",
          content: `🔒 DECISION SEALED: Cryptographic block hash registered in Project-Mono lineage ledger. Consensus achieved. Task deployed under ALGA_FOLD_KERNEL.`,
          codex_compliant: true,
          requires_response: false
        }
      );
      return {
        internal_thoughts: thoughts,
        messages,
        is_malicious: false,
        verdict: "APPROVED"
      };
    }
  };

  const playDialogueSequence = (data: any) => {
    const { internal_thoughts, messages, verdict } = data;
    const thread_id = "thr_" + Math.random().toString(36).substring(2, 8);
    const timeStr = () => new Date().toLocaleTimeString();

    // Start a new thread
    setCurrentThread({
      thread_id,
      subject: prompt.length > 60 ? prompt.substring(0, 57) + "..." : prompt,
      participants: Object.keys(AGENTS_METADATA),
      messages: [],
      status: "open",
      created_at: new Date().toISOString()
    });

    const addDelayedAction = (delay: number, action: () => void) => {
      const adjustedDelay = delay / speedMultiplier;
      const ref = setTimeout(action, adjustedDelay);
      timeoutRefs.current.push(ref);
    };

    // Stagger thoughts loading
    addDelayedAction(100, () => {
      // Clear initial loading thoughts first
      setWindows((prev) => {
        const next = { ...prev };
        Object.keys(next).forEach((name) => {
          next[name] = {
            ...next[name],
            internal_thoughts: []
          };
        });
        return next;
      });
    });

    addDelayedAction(200, () => {
      Object.keys(internal_thoughts).forEach((agentName) => {
        const agentThoughts = internal_thoughts[agentName];
        if (Array.isArray(agentThoughts)) {
          agentThoughts.forEach((thoughtText) => {
            recordAgentThought(agentName, thoughtText);
          });
        }
      });
    });

    let currentDelay = 1200;
    const staggerTime = 2500; // Give slightly more time for deep Gemini responses

    messages.forEach((msg: any, index: number) => {
      addDelayedAction(currentDelay, () => {
        // Set active message ID
        setActiveMessageId(msg.id || `msg_${index}`);

        // Determine phase/simStep based on message type
        if (msg.type === "question" || msg.type === "response") {
          setSimStep(2);
        } else if (msg.type === "approval" || msg.type === "objection") {
          setSimStep(3);
        } else if (msg.type === "request_audit") {
          setSimStep(4);
        } else if (msg.type === "decision") {
          setSimStep(4);
        }

        // Set speaking state
        setWindows((prev) => {
          if (!prev[msg.sender]) return prev;
          
          // Set others to listening or complete
          const next = { ...prev };
          Object.keys(next).forEach((name) => {
            if (name === msg.sender) {
              next[name] = {
                ...next[name],
                status: "speaking"
              };
            } else if (next[name].status !== "blocked" && next[name].status !== "complete") {
              next[name] = {
                ...next[name],
                status: "listening"
              };
            }
          });
          return next;
        });

        // Route the message to the bus and other agent inboxes
        routeMessage({
          id: msg.id || `msg_${index}`,
          sender: msg.sender,
          recipient: msg.recipient,
          type: msg.type as MessageType,
          content: msg.content,
          timestamp: timeStr(),
          codex_compliant: msg.codex_compliant ?? true,
          requires_response: msg.requires_response ?? false
        });

        // If objection block, run lockdown flow
        if (msg.type === "objection") {
          setLockdownMode(true);
          setWindows((prev) => {
            const next = { ...prev };
            Object.keys(next).forEach((name) => {
              next[name] = {
                ...next[name],
                status: "blocked",
                current_task: "WORKSPACE LOCKED BY CONSTITUTIONAL COURT"
              };
            });
            return next;
          });

          setLedgerLog((prev) => [
            {
              timestamp: new Date().toLocaleTimeString(),
              action: "GOVERNANCE SHIELD INTERCEPTED: Malicious payload quarantined.",
              hash: "ERROR_FAIL_CLOSED_LOCKDOWN"
            },
            ...prev
          ]);

          setIsSimulating(false);
        }

        // If decision message, run seal block flow
        if (msg.type === "decision") {
          const blockHash = "sha256_" + Math.random().toString(36).substring(2, 10) + Math.random().toString(36).substring(2, 10);
          
          setLedgerLog((prev) => [
            {
              timestamp: new Date().toLocaleTimeString(),
              action: `Sovereign block sealed: "${prompt.substring(0, 30)}..."`,
              hash: blockHash.substring(0, 16) + "..."
            },
            ...prev
          ]);

          setWindows((prev) => {
            const next = { ...prev };
            Object.keys(next).forEach((name) => {
              next[name] = {
                ...next[name],
                status: "complete",
                current_task: "Idle (Consensus completed)"
              };
            });
            return next;
          });

          setSimStep(5);
          setIsSimulating(false);
        }
      });

      currentDelay += staggerTime;
    });
  };

  const startSimulation = async () => {
    resetObservatory();
    setIsSimulating(true);
    setSimStep(1);

    // Initial loading thoughts for all 7 agents
    Object.keys(AGENTS_METADATA).forEach((name) => {
      recordAgentThought(name, "Contacting sovereign Gemini API mesh to retrieve contextual dialogue thoughts...");
    });

    const API_BASE = import.meta.env.VITE_API_URL ?? "";

    try {
      const response = await fetch(`${API_BASE}/api/observatory/dialogue`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt.trim() })
      });

      if (!response.ok) {
        throw new Error(`Observatory API error: ${response.status}`);
      }

      const data = await response.json();
      playDialogueSequence(data);
    } catch (err) {
      console.warn("Failed to generate dialogue via Gemini, using local fallback generator:", err);
      const offlineDialogue = generateLocalOfflineDialogue(prompt);
      playDialogueSequence(offlineDialogue);
    }
  };

  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "thinking": return "#b45309"; // Amber
      case "speaking": return "#15803d"; // Green
      case "listening": return "#0369a1"; // Blue
      case "blocked": return "#991b1b"; // Red
      case "complete": return "#4f46e5"; // Indigo
      default: return "#334155"; // Slate
    }
  };

  return (
    <div style={styles.observatoryContainer}>
      
      {/* ── Control Header ── */}
      <div style={styles.controlPanel}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <Activity style={{ color: "#818cf8", animation: isSimulating ? "pulse 1.5s infinite" : "none" }} size={24} />
              <h2 style={styles.sectionTitle}>🔭 Colony Observatory & Message Bus</h2>
            </div>
            <p style={styles.sectionSub}>7-AGENT MULTI-WINDOW REASONING & PROTOCOL ENGINE | Node 001</p>
          </div>

          {/* Quick Metrics */}
          <div style={styles.metricsRow}>
            <div style={styles.metricCard}>
              <span style={styles.metricLabel}>Session Coordinates</span>
              <span style={styles.metricValue}>{session_id}</span>
            </div>
            <div style={styles.metricCard}>
              <span style={styles.metricLabel}>Colony Status</span>
              <span style={{
                ...styles.metricValue,
                color: lockdownMode ? "#ef4444" : isSimulating ? "#fbbf24" : "#10b981"
              }}>
                {lockdownMode ? "FAIL-CLOSED" : isSimulating ? "COMMUNICATING" : "STANDBY / ACTIVE"}
              </span>
            </div>
            <div style={styles.metricCard}>
              <span style={styles.metricLabel}>Kernel Shielding</span>
              <span style={{ ...styles.metricValue, color: "#818cf8" }}>
                100% SECURE
              </span>
            </div>
          </div>
        </div>

        {/* Custom prompt or templates selection */}
        <div style={{ marginTop: 20 }}>
          <h3 style={styles.subLabel}>1. Choose Workspace Coordinates (Task Prompt)</h3>
          <div style={styles.templateGrid}>
            {TEMPLATE_PROMPTS.map((t) => (
              <button
                key={t.id}
                onClick={() => selectTemplate(t.prompt)}
                style={{
                  ...styles.templateBtn,
                  borderColor: prompt === t.prompt ? "#6366f1" : "#1e293b",
                  backgroundColor: prompt === t.prompt ? "#1e1b4b" : "#0f172a",
                  color: t.isMalicious ? "#fca5a5" : "#e2e8f0"
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span>{t.label}</span>
                </div>
              </button>
            ))}
          </div>

          <div style={{ position: "relative", marginTop: 12 }}>
            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Input task coordinates for parallel reasoning audit..."
              style={styles.observatoryTextarea}
              rows={3}
              disabled={isSimulating}
            />
            
            <div style={{ display: "flex", gap: 12, marginTop: 12, justifyContent: "space-between", flexWrap: "wrap" }}>
              <div style={{ display: "flex", gap: 12 }}>
                <button
                  onClick={startSimulation}
                  disabled={isSimulating || !prompt.trim()}
                  style={{
                    ...styles.primaryBtn,
                    opacity: isSimulating || !prompt.trim() ? 0.6 : 1,
                    cursor: isSimulating || !prompt.trim() ? "not-allowed" : "pointer"
                  }}
                >
                  <Send size={16} />
                  Execute Inter-Agent Dialogue
                </button>

                <button onClick={resetObservatory} style={styles.secondaryBtn}>
                  <RotateCcw size={16} />
                  Reset Environment
                </button>
              </div>

              {/* Speed Multiplier */}
              <div style={{ display: "flex", alignItems: "center", gap: 8, backgroundColor: "#1e293b", padding: "4px 12px", borderRadius: 6, border: "1px solid #334155" }}>
                <Sliders size={14} style={{ color: "#94a3b8" }} />
                <span style={{ fontSize: 12, color: "#94a3b8" }}>Dialogue Speed:</span>
                <select
                  value={speedMultiplier}
                  onChange={(e) => setSpeedMultiplier(Number(e.target.value))}
                  style={{ backgroundColor: "transparent", color: "#fff", border: "none", outline: "none", fontSize: 12, fontWeight: 600, cursor: "pointer" }}
                  disabled={isSimulating}
                >
                  <option value={1} style={{ background: "#0f172a" }}>1.0x (Standard)</option>
                  <option value={1.5} style={{ background: "#0f172a" }}>1.5x (Fast)</option>
                  <option value={2.5} style={{ background: "#0f172a" }}>2.5x (Hyper)</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ── LOCKDOWN STATE ALERT ── */}
      {lockdownMode && (
        <div style={styles.lockdownAlert}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <BadgeAlert size={28} style={{ color: "#ef4444" }} />
            <div>
              <h3 style={{ margin: 0, fontSize: 15, color: "#fca5a5" }}>🔒 CONSTITUTIONAL FAIL-CLOSED BLOCKAGE ENFORCED</h3>
              <p style={{ margin: "4px 0 0", fontSize: 13, color: "#f87171" }}>
                An exfiltration attempt was intercepted. Codex Guardian locked all other agent subprocesses to protect community assets.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ── ACTIVE THREAD & LIVE BUS LOGS PANEL ── */}
      {currentThread && (
        <div style={styles.threadSection}>
          <div style={styles.threadHeader}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <MessageSquare size={18} style={{ color: "#818cf8" }} />
              <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>
                Active Thread: {currentThread.subject}
              </h3>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 11, fontFamily: "monospace", color: "#64748b" }}>
                ID: {currentThread.thread_id}
              </span>
              <span style={{
                fontSize: 10,
                fontWeight: 700,
                padding: "2px 8px",
                borderRadius: 4,
                backgroundColor: currentThread.status === "blocked" ? "#991b1b" : currentThread.status === "resolved" ? "#15803d" : "#1e1b4b",
                color: "#fff"
              }}>
                {currentThread.status.toUpperCase()}
              </span>
            </div>
          </div>

          {/* Side-by-side interactive split panel */}
          <div style={{
            display: "grid",
            gridTemplateColumns: "minmax(0, 1.2fr) minmax(0, 1fr)",
            backgroundColor: "#030712",
            borderTop: "1px solid #1e293b"
          }} className="grid grid-cols-1 lg:grid-cols-2">

            {/* Left Column: Chat Conversation Stream */}
            <div style={{
              padding: 16,
              maxHeight: "420px",
              overflowY: "auto",
              borderRight: "1px solid #1e293b",
              display: "flex",
              flexDirection: "column"
            }} className="border-r-0 lg:border-r border-b lg:border-b-0 border-[#1e293b]">
              {currentThread.messages.length === 0 ? (
                <div style={styles.emptyThreadMessage}>
                  <Terminal size={24} style={{ color: "#334155", marginBottom: 8 }} />
                  <span>Synchronizing Gemini API mesh... Preparing consensus packets.</span>
                </div>
              ) : (
                <div style={styles.threadMessagesList}>
                  {currentThread.messages.map((msg, i) => {
                    const meta = AGENTS_METADATA[msg.sender] || { color: "#94a3b8" };
                    const isActive = activeMessageId === msg.id;
                    const initials = msg.sender === "Codex Guardian" ? "CG" :
                                     msg.sender === "Research Worker" ? "RW" :
                                     msg.sender === "Builder" ? "B" :
                                     msg.sender === "Colony Manager" ? "CM" :
                                     msg.sender === "Economist" ? "E" :
                                     msg.sender === "Diplomat" ? "D" : "W";

                    return (
                      <div key={msg.id} style={{
                        ...styles.threadMessageRow,
                        borderLeft: `3px solid ${meta.color}`,
                        boxShadow: isActive ? `0 0 12px ${meta.color}22` : "none",
                        borderColor: isActive ? meta.color : "#1f2937",
                        transform: isActive ? "scale(1.01)" : "scale(1)",
                        transition: "all 0.2s ease-in-out",
                        backgroundColor: isActive ? "#0e1322" : "#090d16"
                      }}>
                        <div style={styles.threadMessageMeta}>
                          {/* Mini Avatar Pill */}
                          <span style={{
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                            width: 18,
                            height: 18,
                            borderRadius: "50%",
                            fontSize: 8,
                            fontWeight: 800,
                            backgroundColor: `${meta.color}22`,
                            color: meta.color,
                            border: `1px solid ${meta.color}44`,
                            marginRight: 4
                          }}>
                            {initials}
                          </span>
                          <strong style={{ color: meta.color }}>{msg.sender}</strong>
                          <span style={styles.recipientBadge}>
                            → {msg.recipient}
                          </span>
                          <span style={{
                            ...styles.msgTypeBadge,
                            backgroundColor: msg.type === MessageType.OBJECTION ? "#991b1b" : msg.type === MessageType.APPROVAL ? "#15803d" : "#312e81"
                          }}>
                            {msg.type.toUpperCase()}
                          </span>
                          {isActive && (
                            <span style={{
                              marginLeft: 8,
                              fontSize: 10,
                              color: "#f59e0b",
                              fontWeight: 700,
                              display: "flex",
                              alignItems: "center",
                              gap: 4
                            }} className="animate-pulse">
                              <span style={{ display: "inline-block", width: 6, height: 6, borderRadius: "50%", backgroundColor: "#f59e0b" }} />
                              SPEAKING
                            </span>
                          )}
                          <span style={{ marginLeft: "auto", fontSize: 10, color: "#475569" }}>
                            {msg.timestamp}
                          </span>
                        </div>
                        <p style={{
                          ...styles.threadMessageBody,
                          color: isActive ? "#ffffff" : "#e2e8f0"
                        }}>{msg.content}</p>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Right Column: Live SVG Network Mesh Map */}
            <div style={{
              padding: 16,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "#050814",
              position: "relative",
              overflow: "hidden"
            }}>
              <Heatmap data={heatmapData} />
              {/* CSS Animation keyframes for the SVG elements */}
              <style>{`
                @keyframes pulseGlow {
                  0% { transform: scale(1); opacity: 0.3; }
                  50% { transform: scale(1.3); opacity: 0.1; }
                  100% { transform: scale(1); opacity: 0.3; }
                }
                @keyframes particleDash {
                  to { stroke-dashoffset: -40; }
                }
                @keyframes barWave {
                  0%, 100% { height: 4px; }
                  50% { height: 14px; }
                }
              `}</style>

              <div style={{
                position: "absolute",
                top: 12,
                left: 12,
                fontSize: 10,
                fontFamily: "monospace",
                color: "#64748b",
                zIndex: 10,
                display: "flex",
                alignItems: "center",
                gap: 6
              }}>
                <Activity size={12} style={{ color: "#10b981" }} className="animate-pulse" />
                <span>LIVE SYSTEM PROTOCOL BUS</span>
              </div>

              <AgentTopologyMap />


              {/* Status panel footer */}
              <div style={{
                marginTop: "auto",
                width: "100%",
                padding: "6px 10px",
                backgroundColor: "#0d1324",
                borderRadius: 6,
                border: "1px solid #1e293b",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                fontSize: 10.5,
                fontFamily: "monospace"
              }}>
                <span style={{ color: "#64748b" }}>Sender:</span>
                <span style={{
                  color: activeMsg?.sender ? (AGENTS_METADATA[activeMsg.sender]?.color || "#fff") : "#475569",
                  fontWeight: 700
                }}>
                  {activeMsg?.sender ? activeMsg.sender : "Standby"}
                </span>
                <span style={{ color: "#1e293b" }}>|</span>
                <span style={{ color: "#64748b" }}>Recipient:</span>
                <span style={{
                  color: activeMsg?.recipient ? (activeMsg.recipient === "all" ? "#f59e0b" : (AGENTS_METADATA[activeMsg.recipient]?.color || "#fff")) : "#475569",
                  fontWeight: 700
                }}>
                  {activeMsg?.recipient ? activeMsg.recipient.toUpperCase() : "None"}
                </span>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* ── Seven Sovereign Agent reasoning windows ── */}
      <h3 style={{ ...styles.subLabel, marginTop: 12 }}>
        2. Parallel Agent Minds (Reasoning Coordinates)
      </h3>
      <div style={styles.windowsGrid}>
        {Object.entries(AGENTS_METADATA).map(([name, meta]) => {
          const win = windows[name];
          const IconComponent = meta.icon;
          const isSelected = activeConsoleAgent === name;

          return (
            <div
              key={name}
              onClick={() => setActiveConsoleAgent(name)}
              style={{
                ...styles.windowCard,
                borderColor: isSelected ? meta.color : win.status === "blocked" ? "#ef4444" : "#1e293b",
                cursor: "pointer",
                boxShadow: isSelected ? `0 0 16px ${meta.color}22` : "none"
              }}
            >
              {/* Header */}
              <div style={styles.windowHeader}>
                <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      width: 28,
                      height: 28,
                      borderRadius: 6,
                      backgroundColor: `${meta.color}22`,
                      color: meta.color
                    }}
                  >
                    <IconComponent size={14} />
                  </div>
                  <div>
                    <h4 style={styles.agentTitle}>{name}</h4>
                    <span style={styles.agentSubtitle}>{meta.role}</span>
                  </div>
                </div>

                {/* Status Indicator */}
                <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span
                    style={{
                      display: "inline-block",
                      width: 8,
                      height: 8,
                      borderRadius: "50%",
                      backgroundColor: getStatusBadgeColor(win.status),
                      boxShadow: win.status === "thinking" || win.status === "speaking" ? `0 0 8px ${getStatusBadgeColor(win.status)}` : "none"
                    }}
                  />
                  <span style={{ fontSize: 10, fontWeight: 700, color: "#94a3b8" }}>
                    {win.status.toUpperCase()}
                  </span>
                </div>
              </div>

              {/* Backstory */}
              <div style={styles.agentBackstory}>
                <span>{meta.backstory}</span>
              </div>

              {/* Miniature telemetry */}
              <div style={styles.miniTelemetry}>
                <span>LLM: {meta.model}</span>
                <span>Sent: {win.messages_sent.length}</span>
                <span>Recv: {win.messages_received.length}</span>
              </div>

              {/* Preview of latest internal state */}
              <div style={styles.miniThoughtsPreview}>
                <div style={{ fontSize: 10, color: "#64748b", fontWeight: 700, marginBottom: 4, display: "flex", justifyContent: "space-between" }}>
                  <span>LATEST THOUGHTS</span>
                  <ChevronRight size={10} />
                </div>
                <p style={{ margin: 0, fontSize: 11, color: "#cbd5e1", lineHeight: 1.4, overflow: "hidden", textOverflow: "ellipsis", display: "-webkit-box", WebKitLineClamp: 2, WebKitBoxOrient: "vertical" }}>
                  {win.internal_thoughts.length > 0 
                    ? win.internal_thoughts[win.internal_thoughts.length - 1]
                    : "Awaiting coordinate initialization..."
                  }
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {/* ── DEEP AGENT CONSOLE VIEW ── */}
      <div style={styles.consoleContainer}>
        <div style={styles.consoleHeader}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {React.createElement(AGENTS_METADATA[activeConsoleAgent].icon, {
              size: 18,
              style: { color: AGENTS_METADATA[activeConsoleAgent].color }
            })}
            <h3 style={{ margin: 0, fontSize: 15, fontWeight: 700 }}>
              Sovereign Mind: <span style={{ color: AGENTS_METADATA[activeConsoleAgent].color }}>{activeConsoleAgent}</span>
            </h3>
          </div>

          <div style={styles.tabButtonsRow}>
            <button
              onClick={() => setConsoleTab("thoughts")}
              style={{
                ...styles.consoleTabBtn,
                backgroundColor: consoleTab === "thoughts" ? "#1e293b" : "transparent",
                color: consoleTab === "thoughts" ? "#fff" : "#94a3b8"
              }}
            >
              <Terminal size={12} />
              Internal Reasoner
            </button>
            <button
              onClick={() => setConsoleTab("inbox")}
              style={{
                ...styles.consoleTabBtn,
                backgroundColor: consoleTab === "inbox" ? "#1e293b" : "transparent",
                color: consoleTab === "inbox" ? "#fff" : "#94a3b8"
              }}
            >
              <Mail size={12} />
              Inbox ({windows[activeConsoleAgent].messages_received.length})
            </button>
            <button
              onClick={() => setConsoleTab("outbox")}
              style={{
                ...styles.consoleTabBtn,
                backgroundColor: consoleTab === "outbox" ? "#1e293b" : "transparent",
                color: consoleTab === "outbox" ? "#fff" : "#94a3b8"
              }}
            >
              <Send size={12} />
              Outbox ({windows[activeConsoleAgent].messages_sent.length})
            </button>
          </div>
        </div>

        {/* Console view content */}
        <div style={styles.consoleBody}>
          {consoleTab === "thoughts" && (
            <div style={styles.consoleLog}>
              {windows[activeConsoleAgent].internal_thoughts.length === 0 ? (
                <div style={styles.emptyConsoleMessage}>
                  <span>No internal thoughts cached. Start the dialogue simulation.</span>
                </div>
              ) : (
                windows[activeConsoleAgent].internal_thoughts.map((th, idx) => (
                  <div key={idx} style={styles.consoleLogLine}>
                    <span style={{ color: "#818cf8" }}>&gt;&gt;</span> {th}
                  </div>
                ))
              )}
            </div>
          )}

          {consoleTab === "inbox" && (
            <div style={styles.mailList}>
              {windows[activeConsoleAgent].messages_received.length === 0 ? (
                <div style={styles.emptyConsoleMessage}>
                  <span>Inbox is currently empty.</span>
                </div>
              ) : (
                windows[activeConsoleAgent].messages_received.map((msg) => (
                  <div key={msg.id} style={styles.mailItem}>
                    <div style={styles.mailMeta}>
                      <span style={{ fontWeight: 600, color: AGENTS_METADATA[msg.sender]?.color || "#94a3b8" }}>
                        From: {msg.sender}
                      </span>
                      <span style={styles.mailType}>
                        {msg.type.toUpperCase()}
                      </span>
                      <span style={{ marginLeft: "auto" }}>{msg.timestamp}</span>
                    </div>
                    <p style={styles.mailBody}>{msg.content}</p>
                  </div>
                ))
              )}
            </div>
          )}

          {consoleTab === "outbox" && (
            <div style={styles.mailList}>
              {windows[activeConsoleAgent].messages_sent.length === 0 ? (
                <div style={styles.emptyConsoleMessage}>
                  <span>No outgoing messages registered.</span>
                </div>
              ) : (
                windows[activeConsoleAgent].messages_sent.map((msg) => (
                  <div key={msg.id} style={styles.mailItem}>
                    <div style={styles.mailMeta}>
                      <span style={{ fontWeight: 600, color: "#fff" }}>
                        To: {msg.recipient}
                      </span>
                      <span style={styles.mailType}>
                        {msg.type.toUpperCase()}
                      </span>
                      <span style={{ marginLeft: "auto" }}>{msg.timestamp}</span>
                    </div>
                    <p style={styles.mailBody}>{msg.content}</p>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* ── Global Message Bus & Ledger ── */}
      <div style={styles.auditGrid}>
        
        {/* Real-time Bus Monitor */}
        <div style={styles.auditCard}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <Activity size={16} style={{ color: "#fbbf24" }} />
            <h4 style={styles.auditTitle}>🛰️ Real-time Bus Packet Analyzer</h4>
          </div>

          {liveBusLogs.length === 0 ? (
            <p style={styles.emptyText}>No packets routed. Initiate protocol execution above.</p>
          ) : (
            <div style={styles.auditList}>
              {liveBusLogs.map((log) => (
                <div key={log.id} style={styles.packetItem}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{
                        ...styles.hashTag,
                        backgroundColor: "#1e293b",
                        color: AGENTS_METADATA[log.sender]?.color || "#94a3b8"
                      }}>
                        {log.sender}
                      </span>
                      <span style={{ fontSize: 11, color: "#94a3b8" }}>→</span>
                      <span style={{
                        ...styles.hashTag,
                        backgroundColor: "#111827",
                        color: log.recipient === "all" ? "#f59e0b" : (AGENTS_METADATA[log.recipient]?.color || "#94a3b8")
                      }}>
                        {log.recipient}
                      </span>
                    </div>
                    <span style={{ fontSize: 9, fontFamily: "monospace", color: "#4b5563" }}>
                      ID: {log.id}
                    </span>
                  </div>
                  <p style={{ margin: "6px 0 0", fontSize: 12, color: "#cbd5e1" }}>
                    {log.content.substring(0, 100)}{log.content.length > 100 ? "..." : ""}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Ledger Lineage */}
        <div style={styles.auditCard}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 12 }}>
            <Fingerprint size={16} style={{ color: "#a78bfa" }} />
            <h4 style={styles.auditTitle}>⛓️ Immutable Provenance Block Ledger</h4>
          </div>

          {ledgerLog.length === 0 ? (
            <p style={styles.emptyText}>Ledger silent. Deploy a crew to seal the genesis block.</p>
          ) : (
            <div style={styles.auditList}>
              {ledgerLog.map((log, idx) => (
                <div key={idx} style={styles.ledgerItem}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                    <span style={styles.hashTag}>BLOCK {ledgerLog.length - idx}</span>
                    <span style={{ fontSize: 12, color: "#cbd5e1" }}>{log.action}</span>
                  </div>
                  <span style={styles.hashValue}>{log.hash}</span>
                </div>
              ))}
            </div>
          )}
        </div>

      </div>

    </div>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  observatoryContainer: {
    display: "flex",
    flexDirection: "column",
    gap: 16,
    color: "#f1f5f9"
  },
  controlPanel: {
    backgroundColor: "#111827",
    border: "1px solid #334155",
    borderRadius: 12,
    padding: 20
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 700,
    margin: 0,
    color: "#fff"
  },
  sectionSub: {
    fontSize: 11,
    color: "#94a3b8",
    margin: "4px 0 0",
    fontFamily: "monospace",
    letterSpacing: "0.05em"
  },
  metricsRow: {
    display: "flex",
    gap: 12,
    flexWrap: "wrap",
    marginTop: 8
  },
  metricCard: {
    backgroundColor: "#1e293b",
    border: "1px solid #334155",
    borderRadius: 8,
    padding: "8px 14px",
    display: "flex",
    flexDirection: "column"
  },
  metricLabel: {
    fontSize: 10,
    color: "#64748b",
    textTransform: "uppercase",
    letterSpacing: "0.05em"
  },
  metricValue: {
    fontSize: 12,
    fontWeight: 600,
    fontFamily: "monospace",
    color: "#38bdf8"
  },
  subLabel: {
    fontSize: 13,
    fontWeight: 600,
    color: "#94a3b8",
    marginBottom: 8,
    textTransform: "uppercase",
    letterSpacing: "0.05em"
  },
  templateGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
    gap: 8,
    marginBottom: 12
  },
  templateBtn: {
    padding: "10px 14px",
    borderRadius: 6,
    border: "1px solid",
    fontSize: 12,
    fontWeight: 600,
    textAlign: "left",
    cursor: "pointer",
    transition: "all 0.2s"
  },
  observatoryTextarea: {
    width: "100%",
    padding: 12,
    borderRadius: 8,
    border: "1px solid #334155",
    backgroundColor: "#1e293b",
    color: "#e2e8f0",
    fontSize: 13,
    lineHeight: 1.5,
    resize: "vertical",
    boxSizing: "border-box",
    fontFamily: "monospace"
  },
  primaryBtn: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 18px",
    backgroundColor: "#4f46e5",
    color: "#fff",
    border: "none",
    borderRadius: 6,
    fontSize: 13,
    fontWeight: 600,
    transition: "background-color 0.2s"
  },
  secondaryBtn: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "10px 18px",
    backgroundColor: "transparent",
    color: "#cbd5e1",
    border: "1px solid #475569",
    borderRadius: 6,
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
    transition: "all 0.2s"
  },
  lockdownAlert: {
    backgroundColor: "#450a0a",
    border: "1px solid #ef4444",
    borderRadius: 10,
    padding: "14px 20px"
  },
  threadSection: {
    backgroundColor: "#0b0f19",
    border: "1px solid #334155",
    borderRadius: 12,
    overflow: "hidden"
  },
  threadHeader: {
    backgroundColor: "#111827",
    borderBottom: "1px solid #1e293b",
    padding: "12px 16px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center"
  },
  threadContentContainer: {
    maxHeight: 280,
    overflowY: "auto",
    padding: 16,
    backgroundColor: "#030712"
  },
  emptyThreadMessage: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    padding: "40px 0",
    fontSize: 12,
    color: "#475569",
    textAlign: "center"
  },
  threadMessagesList: {
    display: "flex",
    flexDirection: "column",
    gap: 12
  },
  threadMessageRow: {
    backgroundColor: "#090d16",
    border: "1px solid #1f2937",
    padding: 12,
    borderRadius: 6
  },
  threadMessageMeta: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 11,
    marginBottom: 6
  },
  recipientBadge: {
    fontSize: 10,
    color: "#64748b",
    backgroundColor: "#1e293b",
    padding: "1px 6px",
    borderRadius: 4
  },
  msgTypeBadge: {
    fontSize: 9,
    color: "#fff",
    backgroundColor: "#312e81",
    padding: "1px 6px",
    borderRadius: 4,
    fontWeight: 700
  },
  threadMessageBody: {
    margin: 0,
    fontSize: 12.5,
    color: "#e2e8f0",
    lineHeight: 1.4,
    fontFamily: "monospace"
  },
  windowsGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))",
    gap: 12
  },
  windowCard: {
    backgroundColor: "#111827",
    borderTop: "3px solid",
    borderLeft: "1px solid #1e293b",
    borderRight: "1px solid #1e293b",
    borderBottom: "1px solid #1e293b",
    borderRadius: 8,
    padding: 12,
    display: "flex",
    flexDirection: "column",
    transition: "all 0.2s",
    minHeight: 180
  },
  windowHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 6
  },
  agentTitle: {
    fontSize: 13,
    fontWeight: 700,
    margin: 0,
    color: "#f8fafc"
  },
  agentSubtitle: {
    fontSize: 10,
    color: "#64748b"
  },
  agentBackstory: {
    fontSize: 10.5,
    color: "#94a3b8",
    lineHeight: 1.3,
    marginBottom: 8,
    flex: 1
  },
  miniTelemetry: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: 9,
    fontFamily: "monospace",
    color: "#475569",
    borderTop: "1px solid #1f2937",
    paddingTop: 6,
    marginBottom: 6
  },
  miniThoughtsPreview: {
    backgroundColor: "#030712",
    borderRadius: 4,
    padding: 6,
    border: "1px solid #1e293b",
    fontSize: 11
  },
  consoleContainer: {
    backgroundColor: "#111827",
    border: "1px solid #334155",
    borderRadius: 12,
    overflow: "hidden"
  },
  consoleHeader: {
    backgroundColor: "#111827",
    borderBottom: "1px solid #1e293b",
    padding: "10px 16px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    flexWrap: "wrap",
    gap: 12
  },
  tabButtonsRow: {
    display: "flex",
    gap: 4,
    backgroundColor: "#030712",
    padding: 4,
    borderRadius: 6
  },
  consoleTabBtn: {
    display: "flex",
    alignItems: "center",
    gap: 6,
    padding: "6px 12px",
    border: "none",
    borderRadius: 4,
    fontSize: 11,
    fontWeight: 600,
    cursor: "pointer",
    transition: "all 0.2s"
  },
  consoleBody: {
    backgroundColor: "#030712",
    padding: 16,
    minHeight: 160,
    maxHeight: 240,
    overflowY: "auto"
  },
  consoleLog: {
    fontFamily: "monospace",
    fontSize: 12,
    color: "#a7f3d0",
    display: "flex",
    flexDirection: "column",
    gap: 4
  },
  consoleLogLine: {
    lineHeight: 1.4
  },
  emptyConsoleMessage: {
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: 100,
    fontSize: 11,
    color: "#4b5563"
  },
  mailList: {
    display: "flex",
    flexDirection: "column",
    gap: 8
  },
  mailItem: {
    backgroundColor: "#090d16",
    border: "1px solid #1f2937",
    padding: 10,
    borderRadius: 6
  },
  mailMeta: {
    display: "flex",
    justifyContent: "space-between",
    fontSize: 10.5,
    color: "#64748b",
    marginBottom: 4,
    fontWeight: 600
  },
  mailType: {
    backgroundColor: "#1e1b4b",
    color: "#818cf8",
    padding: "1px 6px",
    borderRadius: 4,
    fontSize: 9
  },
  mailBody: {
    margin: 0,
    fontSize: 12,
    color: "#cbd5e1",
    lineHeight: 1.4,
    fontFamily: "monospace"
  },
  auditGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 16,
    marginTop: 12,
    "@media (maxWidth: 768px)": {
      gridTemplateColumns: "1fr"
    }
  },
  auditCard: {
    backgroundColor: "#111827",
    border: "1px solid #334155",
    borderRadius: 12,
    padding: 16,
    minHeight: 220
  },
  auditTitle: {
    fontSize: 13,
    fontWeight: 600,
    color: "#fff",
    margin: 0,
    textTransform: "uppercase",
    letterSpacing: "0.05em"
  },
  emptyText: {
    fontSize: 11,
    color: "#4b5563",
    textAlign: "center",
    marginTop: 50,
    fontFamily: "monospace"
  },
  auditList: {
    display: "flex",
    flexDirection: "column",
    gap: 8,
    maxHeight: 180,
    overflowY: "auto"
  },
  packetItem: {
    backgroundColor: "#030712",
    border: "1px solid #1f2937",
    padding: 8,
    borderRadius: 6
  },
  ledgerItem: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#030712",
    border: "1px solid #1f2937",
    padding: 8,
    borderRadius: 6,
    fontFamily: "monospace",
    fontSize: 11.5
  },
  hashTag: {
    padding: "2px 6px",
    borderRadius: 4,
    fontSize: 10,
    fontWeight: 600,
    fontFamily: "monospace"
  },
  hashValue: {
    color: "#34d399",
    fontSize: 11,
    fontFamily: "monospace"
  }
};
