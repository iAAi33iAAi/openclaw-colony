/**
 * OpenClaw Colony — Seven Agent Interface
 * Task dispatch UI: submits prompts to the colony, displays per-agent outputs
 * and the Aethel sovereignty verdict.
 */

import React, { useState, useEffect, useRef } from "react";
import LoveQualityChecker from "./LoveQualityChecker";
import AgentDashboard from "./AgentDashboard";
import TaskAssignmentPanel, { Task } from "./TaskAssignmentPanel";
import ColonyObservatory from "./ColonyObservatory";
import AgentPerformanceChart from "./components/AgentPerformanceChart";
import AgentResourceSparkline from "./components/AgentResourceSparkline";
import { saveLog, getLogs } from "./lib/db";
import {
  initAuth,
  googleSignIn,
  logout,
  fetchGoogleDocs,
  getGoogleDocContent,
  exportToGoogleDoc,
  GoogleDocFile
} from "./googleDocs";
import {
  FileText,
  Plus,
  RefreshCw,
  Download,
  LogOut,
  ExternalLink,
  Shield,
  Heart,
  Lock,
  AlertCircle,
  Check,
  FileDown,
  FileSpreadsheet
} from "lucide-react";

// ── Types ─────────────────────────────────────────────────────────────────────

interface AgentOutput {
  agent: string;
  domain: string;
  summary: string;
  flags: string[];
  [key: string]: unknown;
}

interface LQDimension {
  name: string;
  weight: number;
  raw_score: number;
  weighted_score: number;
  rationale: string;
}

interface LQScore {
  composite: number;
  passed: boolean;
  threshold: number;
  rejection_reason: string | null;
  dimensions: LQDimension[];
}

interface GateStatus {
  verdict: "PASS" | "FAIL" | "NOT_REACHED";
  reason: string | null;
}

interface ColonyResponse {
  task_id: string;
  prompt: string;
  lq_score: LQScore;
  aethel_verdict: "APPROVED" | "BLOCKED";
  aethel_gates: Record<string, GateStatus>;
  committed_action: string | null;
  lineage_hash: string | null;
  timestamp: string;
  agent_outputs?: Record<string, AgentOutput>;
  offline_mode?: boolean;
}

// ── Constants ─────────────────────────────────────────────────────────────────

export const AGENT_NAMES = [
  "Strategic",
  "Technical",
  "Resources",
  "Communications",
  "Analysis",
  "Quality",
  "Innovation",
];

export const AGENT_COLORS: Record<string, string> = {
  Strategic:      "#6366f1",
  Technical:      "#0ea5e9",
  Resources:      "#22c55e",
  Communications: "#f59e0b",
  Analysis:       "#ec4899",
  Quality:        "#8b5cf6",
  Innovation:     "#14b8a6",
};

const API_BASE = import.meta.env.VITE_API_URL ?? "";

// ── Component ─────────────────────────────────────────────────────────────────

export default function SevenAgentInterface() {
  const [activeTab, setActiveTab]     = useState<"dispatcher" | "chat" | "google_docs" | "observatory" | "logs">("observatory");
  const [prompt, setPrompt]           = useState("");
  const [consent, setConsent]         = useState(true);
  const [loading, setLoading]         = useState(false);
  const [result, setResult]           = useState<ColonyResponse | null>(null);
  const [error, setError]             = useState<string | null>(null);
  const [activeAgent, setActiveAgent] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activityLogs, setActivityLogs] = useState<any[]>([]);
  const [agentRoles, setAgentRoles] = useState<Record<string, string>>(() => {
    return AGENT_NAMES.reduce((acc, name) => ({ ...acc, [name]: "Coordinator" }), {});
  });

  useEffect(() => {
    getLogs().then(setActivityLogs);
  }, []);

  const searchRef = useRef<HTMLInputElement>(null);
  const taskPanelRef = useRef<any>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        taskPanelRef.current?.handleBroadcast();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);
  const [chatHistory, setChatHistory] = useState<Array<{ role: "user" | "model"; parts: Array<{ text: string }> }>>([
    {
      role: "model",
      parts: [{ text: "Greetings, crew member. I am the **Colony Orchestrator**. How can I help you plan, optimize, or evaluate your tasks to align with our Love Quality standards today?" }]
    }
  ]);
  const [chatInput, setChatInput]     = useState("");
  const [chatLoading, setChatLoading] = useState(false);
  const [usePro, setUsePro]           = useState(false);

  // Google Docs Workspace Integration states
  const [user, setUser]                   = useState<any>(null);
  const [accessToken, setAccessToken]     = useState<string | null>(null);
  const [googleDocs, setGoogleDocs]       = useState<GoogleDocFile[]>([]);
  const [selectedDoc, setSelectedDoc]     = useState<{ title: string; text: string } | null>(null);
  const [docsLoading, setDocsLoading]     = useState(false);
  const [docsError, setDocsError]         = useState<string | null>(null);
  const [exporting, setExporting]         = useState(false);
  const [exportedDocId, setExportedDocId] = useState<string | null>(null);
  const [showExportModal, setShowExportModal] = useState(false);
  const [exportTitle, setExportTitle]     = useState("");
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Initialize Auth listeners on mount
  useEffect(() => {
    const unsubscribe = initAuth(
      (u, token) => {
        setUser(u);
        setAccessToken(token);
        setDocsError(null);
      },
      () => {
        setUser(null);
        setAccessToken(null);
      }
    );
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, []);

  // Fetch Google Docs list when access token is available
  useEffect(() => {
    if (accessToken) {
      setDocsLoading(true);
      fetchGoogleDocs(accessToken)
        .then((files) => {
          setGoogleDocs(files);
          setDocsError(null);
        })
        .catch((err) => {
          console.error("Error fetching Google Docs:", err);
          setDocsError("Failed to list Google Docs files. Your access token may have expired. Please sign in again.");
        })
        .finally(() => {
          setDocsLoading(false);
        });
    } else {
      setGoogleDocs([]);
    }
  }, [accessToken]);

  const handleDocsLogin = async () => {
    setDocsLoading(true);
    setDocsError(null);
    try {
      const res = await googleSignIn();
      if (res) {
        setUser(res.user);
        setAccessToken(res.accessToken);
        setSuccessMessage("Authenticated successfully with Google Workspace!");
        setTimeout(() => setSuccessMessage(null), 4000);
      }
    } catch (err: any) {
      console.error("Sign-In failed:", err);
      setDocsError(err.message || "Failed to sign in. Please verify your browser allows popups.");
    } finally {
      setDocsLoading(false);
    }
  };

  const handleDocsLogout = async () => {
    try {
      await logout();
      setUser(null);
      setAccessToken(null);
      setSelectedDoc(null);
      setGoogleDocs([]);
      setSuccessMessage("Signed out of Google Workspace.");
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (err: any) {
      console.error("Logout failed:", err);
    }
  };

  const refreshDocsList = async () => {
    if (!accessToken) return;
    setDocsLoading(true);
    setDocsError(null);
    try {
      const files = await fetchGoogleDocs(accessToken);
      setGoogleDocs(files);
    } catch (err: any) {
      setDocsError("Failed to refresh file list. Try signing in again.");
    } finally {
      setDocsLoading(false);
    }
  };

  const handleSelectDoc = async (docId: string) => {
    if (!accessToken) return;
    setDocsLoading(true);
    setDocsError(null);
    try {
      const content = await getGoogleDocContent(accessToken, docId);
      setSelectedDoc(content);
    } catch (err: any) {
      setDocsError("Failed to retrieve document text content.");
    } finally {
      setDocsLoading(false);
    }
  };

  const handleImportToPrompt = () => {
    if (!selectedDoc) return;
    setPrompt(selectedDoc.text);
    setActiveTab("dispatcher");
    setSuccessMessage(`Loaded document "${selectedDoc.title}" content into the Evaluator prompt!`);
    setTimeout(() => setSuccessMessage(null), 5000);
  };

  const generateReportMarkdown = (res: ColonyResponse): string => {
    let markdown = `====================================================
🦅 OPENCLAW COLONY VERIFICATION REPORT
====================================================

Task ID: ${res.task_id}
Timestamp: ${res.timestamp}
Aethel Sovereignty Verdict: ${res.aethel_verdict}
Lineage Hash: ${res.lineage_hash || "N/A"}

----------------------------------------------------
🛡️ AETHEL VALIDATION GATES VERDICT
----------------------------------------------------
`;

    Object.entries(res.aethel_gates).forEach(([gateName, gate]) => {
      markdown += `* ${gateName.toUpperCase()}: ${gate.verdict}\n`;
      if (gate.reason) {
        markdown += `  Reason: ${gate.reason}\n`;
      }
    });

    markdown += `
----------------------------------------------------
❤️ LOVE QUALITY (LQ) SCORE VERIFICATION
----------------------------------------------------
Composite LQ Score: ${res.lq_score.composite.toFixed(2)} / 1.00
Verdict: ${res.lq_score.passed ? "PASSED (LQ >= 0.85)" : "FAILED (LQ < 0.85)"}
`;

    if (res.lq_score.rejection_reason) {
      markdown += `Rejection Reason: ${res.lq_score.rejection_reason}\n`;
    }

    markdown += `\nDimensions Breakdown:\n`;
    res.lq_score.dimensions.forEach((dim) => {
      markdown += `* ${dim.name} (Weight: ${dim.weight}): Raw: ${dim.raw_score.toFixed(2)}, Weighted: ${dim.weighted_score.toFixed(2)}\n`;
      markdown += `  Rationale: ${dim.rationale}\n`;
    });

    if (res.agent_outputs) {
      markdown += `
----------------------------------------------------
🤖 7 AGENT TEAM DETAILED EVALUATIONS
----------------------------------------------------
`;
      Object.entries(res.agent_outputs).forEach(([agentName, output]) => {
        markdown += `\n### ${agentName} Agent [Domain: ${output.domain}]\n`;
        markdown += `${output.summary}\n`;
        if (output.flags && output.flags.length > 0) {
          markdown += `Flags: ${output.flags.join(", ")}\n`;
        }
      });
    }

    markdown += `\n====================================================
End of OpenClaw Colony Report. Built with Sovereignty-first consent.
====================================================`;

    return markdown;
  };

  const handleExportReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!result || !accessToken || !exportTitle.trim()) return;

    setExporting(true);
    setDocsError(null);
    try {
      const reportContent = generateReportMarkdown(result);
      const docId = await exportToGoogleDoc(accessToken, exportTitle.trim(), reportContent);
      setExportedDocId(docId);
      setShowExportModal(false);
      setSuccessMessage(`Successfully exported report to Google Doc: "${exportTitle}"`);
      setTimeout(() => setSuccessMessage(null), 6000);
    } catch (err: any) {
      console.error("Export failed:", err);
      setDocsError(err.message || "Failed to export report to Google Docs.");
    } finally {
      setExporting(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prompt.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const res = await fetch(`${API_BASE}/api/process`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt: prompt.trim(), human_consent: consent }),
      });

      if (!res.ok) {
        const body = await res.text();
        throw new Error(`Colony API error ${res.status}: ${body}`);
      }

      const data: ColonyResponse = await res.json();
      setResult(data);
      saveLog(data);
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : String(err));
    } finally {
      setLoading(false);
    }
  };

  const handleSendChatMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim() || chatLoading) return;

    const userMessage = chatInput.trim();
    setChatInput("");
    
    const updatedHistory = [
      ...chatHistory,
      { role: "user" as const, parts: [{ text: userMessage }] }
    ];
    setChatHistory(updatedHistory);
    setChatLoading(true);

    try {
      const res = await fetch(`${API_BASE}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: updatedHistory,
          usePro,
        }),
      });

      if (!res.ok) {
        throw new Error(`Chat error ${res.status}: ${await res.text()}`);
      }

      const data = await res.json();
      setChatHistory([
        ...updatedHistory,
        { role: "model" as const, parts: [{ text: data.text }] }
      ]);
    } catch (err: unknown) {
      setChatHistory([
        ...updatedHistory,
        { role: "model" as const, parts: [{ text: `⚠️ **System Error:** Failed to coordinate with Orchestrator. ${err instanceof Error ? err.message : String(err)}` }] }
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  function formatMarkdown(text: string): React.ReactNode[] {
    const lines = text.split("\n");
    return lines.map((line, lineIdx) => {
      let parts: React.ReactNode[] = [];
      let currentText = line;

      // Regex to match **...** or `...`
      const regex = /(\*\*.*?\*\*|`.*?`)/g;
      const matches = line.match(regex);

      if (matches) {
        let lastIndex = 0;
        matches.forEach((match, matchIdx) => {
          const matchPos = currentText.indexOf(match, lastIndex);
          if (matchPos > lastIndex) {
            parts.push(<span key={`text-${lineIdx}-${matchIdx}`}>{currentText.substring(lastIndex, matchPos)}</span>);
          }
          if (match.startsWith("**") && match.endsWith("**")) {
            parts.push(<strong key={`bold-${lineIdx}-${matchIdx}`} style={{ color: "#f8fafc" }}>{match.slice(2, -2)}</strong>);
          } else if (match.startsWith("`") && match.endsWith("`")) {
            parts.push(<code key={`code-${lineIdx}-${matchIdx}`} style={{ fontFamily: "monospace", backgroundColor: "#0f172a", padding: "2px 6px", borderRadius: 4, color: "#a5b4fc" }}>{match.slice(1, -1)}</code>);
          }
          lastIndex = matchPos + match.length;
        });
        if (lastIndex < currentText.length) {
          parts.push(<span key={`text-end-${lineIdx}`}>{currentText.substring(lastIndex)}</span>);
        }
      } else {
        parts.push(<span key={`text-plain-${lineIdx}`}>{line}</span>);
      }

      return (
        <div key={`line-${lineIdx}`} style={{ marginBottom: lineIdx === lines.length - 1 ? 0 : 8, lineHeight: "1.5" }}>
          {parts}
        </div>
      );
    });
  }

  const verdictColor =
    result?.aethel_verdict === "APPROVED" ? "#22c55e" : "#ef4444";

  return (
    <div style={styles.container}>
      {/* ── Header ── */}
      <header style={styles.header}>
        <div style={{ display: "flex", justifyContent: "center", alignItems: "center", gap: 10 }}>
          <h1 style={styles.title}>🦅 OpenClaw Colony</h1>
          <span style={{
            padding: "4px 8px",
            borderRadius: 12,
            fontSize: 11,
            fontWeight: 600,
            backgroundColor: result ? (result.offline_mode ? "#78350f" : "#064e3b") : "#134e4a",
            color: result ? (result.offline_mode ? "#fef3c7" : "#d1fae5") : "#ccfbf1",
            border: `1px solid ${result ? (result.offline_mode ? "#d97706" : "#059669") : "#0d9488"}`
          }}>
            {result ? (result.offline_mode ? "Simulated Core" : "Live Gemini Core") : "Colony Node Active"}
          </span>
        </div>
        <p style={styles.subtitle}>
          Sovereignty-first · 7-Agent · Love Quality Governed
        </p>
      </header>

      {/* ── Tabs ── */}
      <div style={styles.tabContainer}>
        <button
          style={{
            ...styles.tabButton,
            borderBottomColor: activeTab === "observatory" ? "#6366f1" : "transparent",
            color: activeTab === "observatory" ? "#f8fafc" : "#94a3b8",
          }}
          onClick={() => setActiveTab("observatory")}
        >
          🔭 Colony Observatory
        </button>
        <button
          style={{
            ...styles.tabButton,
            borderBottomColor: activeTab === "dispatcher" ? "#6366f1" : "transparent",
            color: activeTab === "dispatcher" ? "#f8fafc" : "#94a3b8",
          }}
          onClick={() => setActiveTab("dispatcher")}
        >
          📋 Task Evaluator
        </button>
        <button
          style={{
            ...styles.tabButton,
            borderBottomColor: activeTab === "chat" ? "#6366f1" : "transparent",
            color: activeTab === "chat" ? "#f8fafc" : "#94a3b8",
          }}
          onClick={() => setActiveTab("chat")}
        >
          💬 Colony Orchestrator Chat
        </button>
        <button
          style={{
            ...styles.tabButton,
            borderBottomColor: activeTab === "google_docs" ? "#6366f1" : "transparent",
            color: activeTab === "google_docs" ? "#f8fafc" : "#94a3b8",
          }}
          onClick={() => setActiveTab("google_docs")}
        >
          📂 Google Docs Workspace
        </button>
        <button
          style={{
            ...styles.tabButton,
            borderBottomColor: activeTab === "logs" ? "#6366f1" : "transparent",
            color: activeTab === "logs" ? "#f8fafc" : "#94a3b8",
          }}
          onClick={() => setActiveTab("logs")}
        >
          🕒 Recent Activity
        </button>
      </div>

      {activeTab === "dispatcher" && (
        <>
          {/* ── Agent grid ── */}
          <section style={styles.agentGrid}>
            {AGENT_NAMES.map((name) => (
              <div
                key={name}
                style={{
                  ...styles.agentCard,
                  borderColor: AGENT_COLORS[name],
                  opacity: loading ? 0.6 : 1,
                }}
                onClick={() => setActiveAgent(activeAgent === name ? null : name)}
              >
                <div
                  style={{
                    ...styles.agentDot,
                    backgroundColor: loading ? "#f59e0b" : "#22c55e",
                  }}
                />
                <span style={styles.agentName}>{name}</span>
                {result?.agent_outputs?.[name] && (
                  <span style={styles.agentCheck}>✓</span>
                )}
                <div style={{ marginTop: 8, fontSize: 11, color: "#94a3b8" }}>
                  {tasks.filter(t => t.assignedAgents.includes(name) && t.status === 'pending').map(t => (
                    <div key={t.id} style={{ marginBottom: 2 }}>• {t.description}</div>
                  ))}
                </div>
                <div style={{ marginTop: 8 }}>
                  <AgentPerformanceChart completed={Math.floor(Math.random() * 20)} failed={Math.floor(Math.random() * 5)} />
                  <AgentResourceSparkline data={Array.from({ length: 60 }, () => Math.random() * 100)} />
                </div>
              </div>
            ))}
          </section>

          {/* ── Agent detail panel ── */}
          {activeAgent && result?.agent_outputs?.[activeAgent] && (
            <div style={styles.agentDetail}>
              <h3 style={{ color: AGENT_COLORS[activeAgent], margin: "0 0 8px" }}>
                {activeAgent} Agent
              </h3>
              <p style={styles.detailText}>
                {result.agent_outputs[activeAgent].summary}
              </p>
              {result.agent_outputs[activeAgent].flags?.length > 0 && (
                <p style={styles.flagText}>
                  ⚠ Flags: {result.agent_outputs[activeAgent].flags.join(", ")}
                </p>
              )}
            </div>
          )}

          <AgentDashboard agentOutputs={result?.agent_outputs} loading={loading} searchQuery={searchQuery} setSearchQuery={setSearchQuery} searchRef={searchRef} agentRoles={agentRoles} setAgentRoles={setAgentRoles} />
          <TaskAssignmentPanel ref={taskPanelRef} agentOutputs={result?.agent_outputs} searchQuery={searchQuery} tasks={tasks} setTasks={setTasks} />

          {/* ── Task input ── */}
          <form onSubmit={handleSubmit} style={styles.form}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: -4 }}>
              <span style={{ fontSize: 13, fontWeight: 600, color: "#94a3b8" }}>Task / Proposal Description</span>
              {accessToken ? (
                <button
                  type="button"
                  onClick={() => setActiveTab("google_docs")}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    backgroundColor: "transparent",
                    border: "none",
                    color: "#818cf8",
                    fontSize: 13,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  <FileText size={14} />
                  Import from Google Docs
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleDocsLogin}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    backgroundColor: "transparent",
                    border: "none",
                    color: "#94a3b8",
                    fontSize: 13,
                    fontWeight: 600,
                    cursor: "pointer",
                  }}
                >
                  <Lock size={14} />
                  Connect Google Docs
                </button>
              )}
            </div>

            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Enter a task, proposal, or decision for the Colony to evaluate, or import from Google Docs above…"
              style={styles.textarea}
              rows={4}
              disabled={loading}
            />

            <label style={styles.consentLabel}>
              <input
                type="checkbox"
                checked={consent}
                onChange={(e) => setConsent(e.target.checked)}
                disabled={loading}
                style={{ marginRight: 8 }}
              />
              I confirm explicit human consent for this action (Gate 1 — Sovereignty)
            </label>

            <button type="submit" disabled={loading || !prompt.trim()} style={styles.button}>
              {loading ? "Colony processing…" : "Submit to Colony"}
            </button>
          </form>

          {/* ── Error ── */}
          {error && (
            <div style={styles.errorBox}>
              <strong>Error:</strong> {error}
            </div>
          )}

          {/* ── Result ── */}
          {result && (
            <div style={styles.resultContainer}>
              {/* Verdict banner */}
              <div style={{ ...styles.verdictBanner, backgroundColor: verdictColor }}>
                <span style={styles.verdictText}>
                  {result.aethel_verdict === "APPROVED" ? "✅ APPROVED" : "🚫 BLOCKED"}
                </span>
                <span style={styles.verdictSub}>
                  Aethel Sovereignty Verdict · Task {result.task_id.slice(0, 8)}
                </span>
              </div>

              {/* Aethel gates */}
              <div style={styles.gatesRow}>
                {Object.entries(result.aethel_gates).map(([key, gate]) => (
                  <div
                    key={key}
                    style={{
                      ...styles.gateCard,
                      borderColor: gate.verdict === "PASS" ? "#22c55e" : "#ef4444",
                    }}
                  >
                    <div style={styles.gateName}>{key.replace("_", " ").toUpperCase()}</div>
                    <div
                      style={{
                        ...styles.gateVerdict,
                        color: gate.verdict === "PASS" ? "#22c55e" : "#ef4444",
                      }}
                    >
                      {gate.verdict}
                    </div>
                    {gate.reason && (
                      <div style={styles.gateReason}>{gate.reason}</div>
                    )}
                  </div>
                ))}
              </div>

              {/* LQ Score panel */}
              <LoveQualityChecker lqScore={result.lq_score} />

              {/* Lineage hash */}
              {result.lineage_hash && (
                <div style={styles.lineageBox}>
                  <strong>Lineage Hash:</strong>{" "}
                  <code style={styles.hashCode}>{result.lineage_hash}</code>
                </div>
              )}

              {/* Export to Google Docs */}
              <div style={{
                backgroundColor: "#1e293b",
                border: "1px dashed #4f46e5",
                borderRadius: 10,
                padding: 16,
                marginTop: 12,
                display: "flex",
                flexDirection: "column",
                gap: 12,
              }}>
                <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                  <FileText size={20} style={{ color: "#818cf8" }} />
                  <div>
                    <h4 style={{ margin: 0, fontSize: 15, fontWeight: 600, color: "#f8fafc" }}>Save Evaluation to Google Docs</h4>
                    <p style={{ margin: 0, fontSize: 12, color: "#94a3b8" }}>Create a clean report in your Google Drive with the 7-Agent logs and Love Quality scorecard.</p>
                  </div>
                </div>

                {accessToken ? (
                  showExportModal ? (
                    <form onSubmit={handleExportReport} style={{ display: "flex", flexDirection: "column", gap: 10, backgroundColor: "#0f172a", padding: 12, borderRadius: 8, border: "1px solid #334155" }}>
                      <div style={{ fontSize: 12, fontWeight: 600, color: "#94a3b8" }}>Document Title:</div>
                      <input
                        type="text"
                        value={exportTitle}
                        onChange={(e) => setExportTitle(e.target.value)}
                        placeholder="e.g. OpenClaw Report - Water Infrastructure Proposal"
                        style={styles.chatInput}
                        required
                        disabled={exporting}
                      />
                      <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "#94a3b8", cursor: "pointer" }}>
                        <input type="checkbox" required disabled={exporting} defaultChecked />
                        I authorize creating this document on my Google Drive
                      </label>
                      <div style={{ display: "flex", gap: 8 }}>
                        <button type="submit" disabled={exporting} style={{ ...styles.chatSendButton, backgroundColor: "#22c55e", padding: "8px 16px", fontSize: 13 }}>
                          {exporting ? "Exporting..." : "Confirm Export"}
                        </button>
                        <button type="button" onClick={() => setShowExportModal(false)} disabled={exporting} style={{ ...styles.chatSendButton, backgroundColor: "#475569", padding: "8px 16px", fontSize: 13 }}>
                          Cancel
                        </button>
                      </div>
                    </form>
                  ) : (
                    <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                      <button
                        onClick={() => {
                          setExportTitle(`[OpenClaw Report] ${result.prompt.slice(0, 40)}${result.prompt.length > 40 ? "..." : ""}`);
                          setShowExportModal(true);
                        }}
                        style={{ ...styles.button, backgroundColor: "#4f46e5", padding: "8px 16px", fontSize: 13, alignSelf: "flex-start" }}
                      >
                        Create Google Doc Report
                      </button>
                      {exportedDocId && (
                        <a
                          href={`https://docs.google.com/document/d/${exportedDocId}/edit`}
                          target="_blank"
                          rel="noopener noreferrer"
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 4,
                            fontSize: 13,
                            color: "#818cf8",
                            fontWeight: 600,
                            textDecoration: "none",
                          }}
                        >
                          <ExternalLink size={14} />
                          Open Document
                        </a>
                      )}
                    </div>
                  )
                ) : (
                  <div>
                    <button
                      onClick={handleDocsLogin}
                      style={{ ...styles.button, backgroundColor: "#4f46e5", padding: "8px 16px", fontSize: 13 }}
                    >
                      Connect Google Workspace to Export
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </>
      )}

      {/* ── Success Toast ── */}
      {successMessage && (
        <div style={{
          position: "fixed",
          bottom: 24,
          right: 24,
          backgroundColor: "#064e3b",
          border: "1px solid #059669",
          color: "#d1fae5",
          padding: "12px 20px",
          borderRadius: 8,
          boxShadow: "0 10px 15px -3px rgba(0,0,0,0.5)",
          zIndex: 100,
          display: "flex",
          alignItems: "center",
          gap: 10,
          fontSize: 14,
        }}>
          <Check size={18} style={{ color: "#34d399" }} />
          <span>{successMessage}</span>
        </div>
      )}

      {activeTab === "chat" && (
        <div style={styles.chatSection}>
          <div style={styles.chatHeader}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <h2 style={{ fontSize: 18, margin: 0, color: "#f8fafc" }}>Orchestration Hub</h2>
              <p style={{ fontSize: 13, color: "#94a3b8", margin: "2px 0 0" }}>Direct consultation with the Colony's governance core</p>
            </div>
            <label style={{ display: "flex", alignItems: "center", fontSize: 13, color: "#94a3b8", cursor: "pointer" }}>
              <input
                type="checkbox"
                checked={usePro}
                onChange={(e) => setUsePro(e.target.checked)}
                style={{ marginRight: 6 }}
              />
              Deep Reasoning Mode (gemini-3.1-pro)
            </label>
          </div>

          <div style={styles.chatHistory}>
            {chatHistory.map((msg, idx) => (
              <div
                key={idx}
                style={{
                  ...styles.chatBubbleContainer,
                  justifyContent: msg.role === "user" ? "flex-end" : "flex-start",
                }}
              >
                <div
                  style={{
                    ...styles.chatBubble,
                    backgroundColor: msg.role === "user" ? "#4f46e5" : "#1e293b",
                    border: msg.role === "user" ? "none" : "1px solid #334155",
                  }}
                >
                  <div style={{ fontSize: 11, fontWeight: 700, textTransform: "uppercase", letterSpacing: "0.05em", color: msg.role === "user" ? "#c7d2fe" : "#818cf8", marginBottom: 6 }}>
                    {msg.role === "user" ? "Crew Member" : "Colony Orchestrator"}
                  </div>
                  <div style={{ fontSize: 14, color: "#cbd5e1" }}>
                    {formatMarkdown(msg.parts[0].text)}
                  </div>
                </div>
              </div>
            ))}
            {chatLoading && (
              <div style={{ ...styles.chatBubbleContainer, justifyContent: "flex-start" }}>
                <div style={{ ...styles.chatBubble, backgroundColor: "#1e293b", border: "1px solid #334155" }}>
                  <span style={{ fontSize: 13, color: "#94a3b8" }}>Orchestrator is thinking...</span>
                </div>
              </div>
            )}
          </div>

          <form onSubmit={handleSendChatMessage} style={styles.chatForm}>
            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              placeholder="Ask the Orchestrator about task design, Love Quality standards..."
              style={styles.chatInput}
              disabled={chatLoading}
            />
            <button type="submit" disabled={chatLoading || !chatInput.trim()} style={styles.chatSendButton}>
              {chatLoading ? "Sending..." : "Send"}
            </button>
          </form>
        </div>
      )}

      {activeTab === "logs" && (
        <div style={styles.chatSection}>
          <div style={styles.chatHeader}>
            <h2 style={{ fontSize: 18, margin: 0, color: "#f8fafc" }}>Recent Activity</h2>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 10, padding: 16 }}>
            {activityLogs.length === 0 ? (
              <div style={{ color: "#94a3b8", textAlign: "center", marginTop: 40 }}>No activity logged yet.</div>
            ) : (
              activityLogs.slice().reverse().map((log, idx) => (
                <div key={idx} style={{ backgroundColor: "#1e293b", padding: 12, borderRadius: 8, fontSize: 13, border: "1px solid #334155" }}>
                  <div style={{ color: "#818cf8", fontSize: 11, marginBottom: 4 }}>{new Date(log.timestamp).toLocaleString()}</div>
                  <div style={{ color: "#e2e8f0" }}>Task Completed: {log.task_id}</div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {activeTab === "google_docs" && (
        <div style={styles.chatSection}>
          <div style={styles.chatHeader}>
            <div style={{ display: "flex", flexDirection: "column" }}>
              <h2 style={{ fontSize: 18, margin: 0, color: "#f8fafc" }}>📂 Google Docs Workspace</h2>
              <p style={{ fontSize: 13, color: "#94a3b8", margin: "2px 0 0" }}>Review, import, and document crew decisions on Google Drive</p>
            </div>
            {accessToken && (
              <button
                onClick={handleDocsLogout}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "6px 12px",
                  fontSize: 12,
                  fontWeight: 600,
                  backgroundColor: "#dc2626",
                  color: "#fff",
                  border: "none",
                  borderRadius: 6,
                  cursor: "pointer"
                }}
              >
                <LogOut size={12} />
                Disconnect
              </button>
            )}
          </div>

          {docsError && (
            <div style={{ ...styles.errorBox, display: "flex", alignItems: "center", gap: 10, marginTop: 12 }}>
              <AlertCircle size={18} />
              <span>{docsError}</span>
            </div>
          )}

          {!accessToken ? (
            <div style={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              padding: "40px 20px",
              backgroundColor: "#1e293b",
              borderRadius: 12,
              border: "1px solid #334155",
              textAlign: "center",
              gap: 16,
              marginTop: 16,
            }}>
              <div style={{
                backgroundColor: "#312e81",
                padding: 16,
                borderRadius: "50%",
                display: "inline-flex"
              }}>
                <FileText size={40} style={{ color: "#818cf8" }} />
              </div>
              <div>
                <h3 style={{ margin: "0 0 8px", fontSize: 18, fontWeight: 700, color: "#f8fafc" }}>Connect Google Workspace</h3>
                <p style={{ margin: 0, fontSize: 14, color: "#94a3b8", maxWidth: 450, lineHeight: "1.5" }}>
                  Integrate Google Drive & Google Docs to pull proposals directly into the Colony task validation engine, or export full audit trails.
                </p>
              </div>

              {/* Official Google Button design */}
              <button
                onClick={handleDocsLogin}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  backgroundColor: "#ffffff",
                  color: "#1f1f1f",
                  border: "1px solid #747775",
                  borderRadius: 4,
                  padding: "10px 16px",
                  fontFamily: "'Roboto', sans-serif",
                  fontSize: 14,
                  fontWeight: 500,
                  cursor: "pointer",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.2)",
                  transition: "background-color 0.2s",
                  marginTop: 8,
                }}
                onMouseOver={(e) => (e.currentTarget.style.backgroundColor = "#f2f2f2")}
                onMouseOut={(e) => (e.currentTarget.style.backgroundColor = "#ffffff")}
              >
                <svg width="18" height="18" viewBox="0 0 18 18">
                  <path fill="#EA4335" d="M9 3.58c1.12 0 2.12.39 2.92 1.15l2.17-2.17C12.78.8 11.02 0 9 0 5.54 0 2.61 2 1.13 4.9l2.84 2.2C4.64 5.07 6.64 3.58 9 3.58z" />
                  <path fill="#4285F4" d="M17.64 9.2c0-.64-.06-1.25-.16-1.84H9v3.47h4.84c-.21 1.12-.84 2.07-1.8 2.7l2.8 2.17c1.64-1.51 2.8-3.74 2.8-6.5z" />
                  <path fill="#FBBC05" d="M3.97 10.7c-.24-.7-.38-1.46-.38-2.2s.14-1.5.38-2.2L1.13 4.9C.41 6.14 0 7.52 0 9s.41 2.86 1.13 4.1l2.84-2.2c-.24-.74-.38-1.5-.38-2.2z" />
                  <path fill="#34A853" d="M9 18c2.43 0 4.47-.8 5.96-2.18l-2.8-2.17c-.78.52-1.78.83-3.16.83-2.36 0-4.36-1.49-5.03-3.52L1.13 13.1C2.61 16 5.54 18 9 18z" />
                </svg>
                Sign in with Google Account
              </button>
            </div>
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginTop: 16, minHeight: 350 }}>
              {/* Left Column: Docs List */}
              <div style={{ display: "flex", flexDirection: "column", gap: 10, backgroundColor: "#1e293b", padding: 16, borderRadius: 10, border: "1px solid #334155" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #334155", paddingBottom: 10, marginBottom: 8 }}>
                  <h3 style={{ margin: 0, fontSize: 14, fontWeight: 600, color: "#cbd5e1" }}>Recent Documents</h3>
                  <button
                    onClick={refreshDocsList}
                    disabled={docsLoading}
                    style={{
                      background: "none",
                      border: "none",
                      color: "#818cf8",
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                      fontSize: 12,
                    }}
                  >
                    <RefreshCw size={12} className={docsLoading ? "animate-spin" : ""} />
                    {docsLoading ? "Loading..." : "Refresh"}
                  </button>
                </div>

                <div style={{ display: "flex", flexDirection: "column", gap: 8, overflowY: "auto", maxHeight: 300, flex: 1 }}>
                  {googleDocs.length === 0 ? (
                    <div style={{ color: "#94a3b8", fontSize: 13, textAlign: "center", padding: "40px 0" }}>
                      No Google Docs found in Drive.
                    </div>
                  ) : (
                    googleDocs.map((doc) => (
                      <div
                        key={doc.id}
                        onClick={() => handleSelectDoc(doc.id)}
                        style={{
                          display: "flex",
                          alignItems: "center",
                          gap: 10,
                          padding: "10px 12px",
                          borderRadius: 8,
                          backgroundColor: "#0f172a",
                          cursor: "pointer",
                          border: "1px solid #1e293b",
                          transition: "border-color 0.2s"
                        }}
                        onMouseOver={(e) => (e.currentTarget.style.borderColor = "#4f46e5")}
                        onMouseOut={(e) => (e.currentTarget.style.borderColor = "#1e293b")}
                      >
                        <FileText size={16} style={{ color: "#818cf8", flexShrink: 0 }} />
                        <span style={{ fontSize: 13, color: "#e2e8f0", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", flex: 1 }}>
                          {doc.name}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              {/* Right Column: Selected Doc Preview */}
              <div style={{ display: "flex", flexDirection: "column", backgroundColor: "#1e293b", padding: 16, borderRadius: 10, border: "1px solid #334155" }}>
                {docsLoading && !selectedDoc ? (
                  <div style={{ display: "flex", flex: 1, alignItems: "center", justifyContent: "center", color: "#94a3b8", fontSize: 13 }}>
                    Retrieving document content...
                  </div>
                ) : selectedDoc ? (
                  <div style={{ display: "flex", flexDirection: "column", flex: 1 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", borderBottom: "1px solid #334155", paddingBottom: 10, marginBottom: 12 }}>
                      <h4 style={{ margin: 0, fontSize: 14, fontWeight: 600, color: "#f8fafc", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "70%" }}>
                        {selectedDoc.title}
                      </h4>
                      <button
                        onClick={() => setSelectedDoc(null)}
                        style={{ background: "none", border: "none", color: "#94a3b8", fontSize: 12, cursor: "pointer" }}
                      >
                        Clear
                      </button>
                    </div>

                    <div style={{
                      backgroundColor: "#0f172a",
                      border: "1px solid #334155",
                      borderRadius: 8,
                      padding: 12,
                      fontSize: 13,
                      color: "#cbd5e1",
                      fontFamily: "monospace",
                      overflowY: "auto",
                      maxHeight: 180,
                      flex: 1,
                      whiteSpace: "pre-wrap",
                      marginBottom: 12,
                    }}>
                      {selectedDoc.text || <em style={{ color: "#64748b" }}>[Empty Document]</em>}
                    </div>

                    <button
                      onClick={handleImportToPrompt}
                      style={{
                        ...styles.button,
                        backgroundColor: "#10b981",
                        width: "100%",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 8,
                        padding: "10px"
                      }}
                    >
                      <Download size={16} />
                      Import text into Evaluator
                    </button>
                  </div>
                ) : (
                  <div style={{ display: "flex", flexDirection: "column", flex: 1, alignItems: "center", justifyContent: "center", color: "#94a3b8", padding: 20, textAlign: "center" }}>
                    <Shield size={24} style={{ color: "#4f46e5", marginBottom: 8 }} />
                    <span style={{ fontSize: 13 }}>Select a document from the left to view and import its contents.</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === "observatory" && <ColonyObservatory />}
    </div>
  );
}

// ── Styles ────────────────────────────────────────────────────────────────────

const styles: Record<string, React.CSSProperties> = {
  container: {
    maxWidth: 900,
    margin: "0 auto",
    padding: "24px 16px",
    fontFamily: "'Inter', system-ui, sans-serif",
    color: "#e2e8f0",
    backgroundColor: "#0f172a",
    minHeight: "100vh",
  },
  header: { textAlign: "center", marginBottom: 32 },
  title: { fontSize: 32, fontWeight: 700, margin: 0, color: "#f8fafc" },
  subtitle: { color: "#94a3b8", margin: "8px 0 0" },
  agentGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fill, minmax(120px, 1fr))",
    gap: 12,
    marginBottom: 24,
  },
  agentCard: {
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    padding: "12px 8px",
    border: "2px solid",
    borderRadius: 10,
    cursor: "pointer",
    backgroundColor: "#1e293b",
    transition: "opacity 0.2s",
    position: "relative",
  },
  agentDot: {
    width: 10,
    height: 10,
    borderRadius: "50%",
    marginBottom: 6,
  },
  agentName: { fontSize: 13, fontWeight: 600, textAlign: "center" },
  agentCheck: { position: "absolute", top: 6, right: 8, color: "#22c55e", fontSize: 12 },
  agentDetail: {
    backgroundColor: "#1e293b",
    border: "1px solid #334155",
    borderRadius: 10,
    padding: 16,
    marginBottom: 20,
  },
  detailText: { fontSize: 14, color: "#cbd5e1", margin: 0 },
  flagText: { fontSize: 13, color: "#f59e0b", marginTop: 8 },
  form: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
    marginBottom: 24,
  },
  textarea: {
    width: "100%",
    padding: 12,
    borderRadius: 8,
    border: "1px solid #334155",
    backgroundColor: "#1e293b",
    color: "#e2e8f0",
    fontSize: 15,
    resize: "vertical",
    boxSizing: "border-box",
  },
  consentLabel: {
    display: "flex",
    alignItems: "center",
    fontSize: 14,
    color: "#94a3b8",
    cursor: "pointer",
  },
  button: {
    padding: "12px 24px",
    backgroundColor: "#6366f1",
    color: "#fff",
    border: "none",
    borderRadius: 8,
    fontSize: 16,
    fontWeight: 600,
    cursor: "pointer",
    alignSelf: "flex-start",
  },
  errorBox: {
    backgroundColor: "#450a0a",
    border: "1px solid #ef4444",
    borderRadius: 8,
    padding: 12,
    color: "#fca5a5",
    marginBottom: 16,
  },
  resultContainer: { display: "flex", flexDirection: "column", gap: 16 },
  verdictBanner: {
    borderRadius: 10,
    padding: "16px 20px",
    display: "flex",
    flexDirection: "column",
    gap: 4,
  },
  verdictText: { fontSize: 22, fontWeight: 700, color: "#fff" },
  verdictSub: { fontSize: 13, color: "rgba(255,255,255,0.8)" },
  gatesRow: { display: "flex", gap: 12, flexWrap: "wrap" },
  gateCard: {
    flex: "1 1 160px",
    border: "2px solid",
    borderRadius: 8,
    padding: 12,
    backgroundColor: "#1e293b",
  },
  gateName: { fontSize: 11, color: "#94a3b8", marginBottom: 4, fontWeight: 600 },
  gateVerdict: { fontSize: 16, fontWeight: 700 },
  gateReason: { fontSize: 12, color: "#94a3b8", marginTop: 6 },
  lineageBox: {
    backgroundColor: "#1e293b",
    border: "1px solid #334155",
    borderRadius: 8,
    padding: 12,
    fontSize: 13,
    color: "#94a3b8",
    wordBreak: "break-all",
  },
  hashCode: {
    fontFamily: "monospace",
    color: "#a5b4fc",
    fontSize: 12,
  },
  tabContainer: {
    display: "flex",
    gap: 16,
    borderBottom: "1px solid #334155",
    marginBottom: 24,
  },
  tabButton: {
    padding: "10px 16px",
    backgroundColor: "transparent",
    border: "none",
    borderBottom: "3px solid transparent",
    fontSize: 16,
    fontWeight: 600,
    cursor: "pointer",
    transition: "border-color 0.2s, color 0.2s",
  },
  chatSection: {
    backgroundColor: "#111827",
    border: "1px solid #334155",
    borderRadius: 12,
    padding: 20,
    display: "flex",
    flexDirection: "column",
    gap: 16,
    minHeight: 450,
  },
  chatHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    borderBottom: "1px solid #1f2937",
    paddingBottom: 12,
  },
  chatHistory: {
    display: "flex",
    flexDirection: "column",
    gap: 12,
    flex: 1,
    maxHeight: 400,
    overflowY: "auto",
    paddingRight: 8,
  },
  chatBubbleContainer: {
    display: "flex",
    width: "100%",
  },
  chatBubble: {
    maxWidth: "80%",
    borderRadius: 12,
    padding: "12px 16px",
  },
  chatForm: {
    display: "flex",
    gap: 10,
  },
  chatInput: {
    flex: 1,
    padding: "12px 16px",
    borderRadius: 8,
    border: "1px solid #334155",
    backgroundColor: "#1e293b",
    color: "#e2e8f0",
    fontSize: 14,
    boxSizing: "border-box",
  },
  chatSendButton: {
    padding: "12px 20px",
    backgroundColor: "#4f46e5",
    color: "#fff",
    border: "none",
    borderRadius: 8,
    fontSize: 14,
    fontWeight: 600,
    cursor: "pointer",
  },
};