import React from "react";

interface AgentSummaryHeaderProps {
  agentOutputs?: Record<string, any>;
}

export default function AgentSummaryHeader({ agentOutputs }: AgentSummaryHeaderProps) {
  const agents = agentOutputs ? Object.values(agentOutputs) : [];
  const totalTasks = agents.length;
  const criticalAgents = agents.filter(a => a.flags && a.flags.length > 0).length;
  const healthStatus = criticalAgents === 0 ? "Healthy" : "Attention Required";

  return (
    <div className="bg-slate-800 p-4 rounded-xl border border-slate-700 mb-4 flex justify-between items-center shadow-lg">
      <div>
        <h3 className="text-sm font-semibold text-slate-400">Total Task Volume</h3>
        <p className="text-2xl font-bold text-white">{totalTasks}</p>
      </div>
      <div>
        <h3 className="text-sm font-semibold text-slate-400">System Health</h3>
        <p className={`text-xl font-bold ${criticalAgents === 0 ? "text-green-500" : "text-red-500"}`}>
          {healthStatus}
        </p>
      </div>
    </div>
  );
}
