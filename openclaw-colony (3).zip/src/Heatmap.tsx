import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

interface HeatmapProps {
  data: Array<{ agent: string; time: number; activity: number }>;
}

export default function Heatmap({ data }: HeatmapProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current || data.length === 0) return;

    const margin = { top: 20, right: 20, bottom: 30, left: 60 };
    const width = 400 - margin.left - margin.right;
    const height = 300 - margin.top - margin.bottom;

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const g = svg.append("g")
      .attr("transform", `translate(${margin.left},${margin.top})`);

    const agents = Array.from(new Set(data.map(d => d.agent)));
    const times = Array.from(new Set(data.map(d => d.time)));

    const x = d3.scaleBand()
      .range([0, width])
      .domain(times.map(String))
      .padding(0.05);

    const y = d3.scaleBand()
      .range([height, 0])
      .domain(agents)
      .padding(0.05);

    const color = d3.scaleSequential(d3.interpolateInferno)
      .domain([0, d3.max(data, d => d.activity) || 1]);

    g.selectAll()
      .data(data)
      .enter()
      .append("rect")
      .attr("x", d => x(String(d.time))!)
      .attr("y", d => y(d.agent)!)
      .attr("width", x.bandwidth())
      .attr("height", y.bandwidth())
      .style("fill", d => color(d.activity));

    g.append("g")
      .attr("transform", `translate(0,${height})`)
      .call(d3.axisBottom(x).tickFormat(() => ""));
    
    g.append("g")
      .call(d3.axisLeft(y));

  }, [data]);

  return <svg ref={svgRef} width="400" height="300" />;
}
