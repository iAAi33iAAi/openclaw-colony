import { openDB } from 'idb';

const DB_NAME = 'ColonyDB';
const DB_VERSION = 1;

export const initDB = async () => {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('logs')) {
        db.createObjectStore('logs', { keyPath: 'id', autoIncrement: true });
      }
      if (!db.objectStoreNames.contains('statusUpdates')) {
        db.createObjectStore('statusUpdates', { keyPath: 'id', autoIncrement: true });
      }
    },
  });
};

export const saveLog = async (log: any) => {
  const db = await initDB();
  return db.add('logs', { ...log, timestamp: Date.now() });
};

export const getLogs = async () => {
  const db = await initDB();
  return db.getAll('logs');
};

export const saveStatus = async (status: any) => {
  const db = await initDB();
  return db.add('statusUpdates', { ...status, timestamp: Date.now() });
};

export const getStatusUpdates = async () => {
  const db = await initDB();
  return db.getAll('statusUpdates');
};
