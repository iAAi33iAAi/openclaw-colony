export const playAudioCue = (status: 'Active' | 'Critical' | 'Idle') => {
  const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
  if (!AudioContext) return;

  const audioContext = new AudioContext();
  const oscillator = audioContext.createOscillator();
  const gainNode = audioContext.createGain();
  
  oscillator.connect(gainNode);
  gainNode.connect(audioContext.destination);
  
  if (status === 'Active') {
    oscillator.type = 'sine';
    oscillator.frequency.value = 440; // A4
  } else if (status === 'Critical') {
    oscillator.type = 'square';
    oscillator.frequency.value = 880; // A5
  } else {
    oscillator.type = 'sine';
    oscillator.frequency.value = 220; // A3
  }
  
  gainNode.gain.setValueAtTime(0.05, audioContext.currentTime); // Gentle volume
  gainNode.gain.exponentialRampToValueAtTime(0.001, audioContext.currentTime + 0.1);
  
  oscillator.start();
  oscillator.stop(audioContext.currentTime + 0.1);
};
