import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

interface PerformanceChartProps {
  completed: number;
  failed: number;
}

export default function AgentPerformanceChart({ completed, failed }: PerformanceChartProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const data = [
      { label: "Done", value: completed, color: "#22c55e" },
      { label: "Fail", value: failed, color: "#ef4444" },
    ];

    const width = 100;
    const height = 40;
    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const x = d3.scaleBand().domain(data.map(d => d.label)).range([0, width]).padding(0.2);
    const y = d3.scaleLinear().domain([0, d3.max(data, d => d.value) || 1]).range([height, 0]);

    svg.selectAll("rect")
      .data(data)
      .enter()
      .append("rect")
      .attr("x", d => x(d.label)!)
      .attr("y", d => y(d.value))
      .attr("width", x.bandwidth())
      .attr("height", d => height - y(d.value))
      .attr("fill", d => d.color);
  }, [completed, failed]);

  return <svg ref={svgRef} width="100" height="40" />;
}
