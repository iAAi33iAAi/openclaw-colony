import React, { useEffect, useRef } from "react";
import * as d3 from "d3";

interface AgentNode extends d3.SimulationNodeDatum {
  id: string;
  color: string;
}

interface Link extends d3.SimulationLinkDatum<AgentNode> {
  source: string | AgentNode;
  target: string | AgentNode;
}

const AGENTS = [
  "Codex Guardian", "Research Worker", "Builder", "Colony Manager", 
  "Economist", "Diplomat", "Witness"
];

const COLORS = ["#818cf8", "#60a5fa", "#34d399", "#f59e0b", "#ec4899", "#a78bfa", "#14b8a6"];

export default function AgentTopologyMap() {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (!svgRef.current) return;

    const width = 400;
    const height = 400;

    const nodes: AgentNode[] = AGENTS.map((id, i) => ({ id, color: COLORS[i] }));
    const links: Link[] = [];
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        links.push({ source: nodes[i].id, target: nodes[j].id });
      }
    }

    const svg = d3.select(svgRef.current);
    svg.selectAll("*").remove();

    const simulation = d3.forceSimulation(nodes)
      .force("link", d3.forceLink(links).id((d: any) => d.id).distance(100))
      .force("charge", d3.forceManyBody().strength(-300))
      .force("center", d3.forceCenter(width / 2, height / 2));

    const link = svg.append("g")
      .selectAll("line")
      .data(links)
      .enter().append("line")
      .attr("stroke", "#1e293b")
      .attr("stroke-width", 1)
      .attr("opacity", 0.3);

    const node = svg.append("g")
      .selectAll("circle")
      .data(nodes)
      .enter().append("circle")
      .attr("r", 10)
      .attr("fill", d => d.color);

    node.append("title").text(d => d.id);

    simulation.on("tick", () => {
      link
        .attr("x1", (d: any) => d.source.x)
        .attr("y1", (d: any) => d.source.y)
        .attr("x2", (d: any) => d.target.x)
        .attr("y2", (d: any) => d.target.y);

      node
        .attr("cx", (d: any) => d.x)
        .attr("cy", (d: any) => d.y);
    });
  }, []);

  return <svg ref={svgRef} width="100%" height="100%" viewBox="0 0 400 400" />;
}
