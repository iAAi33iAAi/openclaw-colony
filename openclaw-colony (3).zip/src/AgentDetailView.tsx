import React from "react";
import { AGENT_NAMES, AGENT_COLORS } from "./SevenAgentInterface";

interface AgentDetailViewProps {
  agentName: string;
  onClose: () => void;
  color: string;
  searchQuery: string;
}

export default function AgentDetailView({ agentName, onClose, color, searchQuery }: AgentDetailViewProps) {
  // Mock data structure
  const logs = ["System initialized", "Task accepted", "Processing request", "Optimization complete"];
  
  const filteredLogs = logs.filter(log => log.toLowerCase().includes(searchQuery.toLowerCase()));
  const tasks = ["Analyze data", "Review reports", "Coordinate with other agents"];
  const metrics = { efficiency: "92%", load: "45%", uptime: "99.9%" };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-lg shadow-2xl">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <div style={{ width: 12, height: 12, borderRadius: '50%', backgroundColor: color }}></div>
            {agentName} Agent Detail
          </h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white">Close</button>
        </div>
        
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold text-indigo-400">Metrics</h3>
            <div className="grid grid-cols-3 gap-2 mt-1">
              {Object.entries(metrics).map(([key, value]) => (
                <div key={key} className="bg-slate-800 p-2 rounded text-center">
                  <div className="text-xs text-slate-400 uppercase">{key}</div>
                  <div className="text-sm font-bold text-white">{value}</div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold text-indigo-400">Active Tasks</h3>
            <ul className="list-disc list-inside text-sm text-slate-300 mt-1">
              {tasks.map((task, i) => <li key={i}>{task}</li>)}
            </ul>
          </div>

          <div>
            <div className="flex justify-between items-center">
              <h3 className="text-sm font-semibold text-indigo-400">Recent Logs</h3>
              <button 
                onClick={() => {
                  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(logs, null, 2));
                  const downloadAnchorNode = document.createElement('a');
                  downloadAnchorNode.setAttribute("href", dataStr);
                  downloadAnchorNode.setAttribute("download", `${agentName}_logs.json`);
                  document.body.appendChild(downloadAnchorNode);
                  downloadAnchorNode.click();
                  downloadAnchorNode.remove();
                }}
                className="text-xs bg-indigo-600 px-2 py-1 rounded hover:bg-indigo-700 text-white"
              >
                Export JSON
              </button>
            </div>
            <div className="bg-slate-800 p-3 rounded text-xs font-mono text-slate-300 mt-1 h-32 overflow-y-auto">
              {filteredLogs.map((log, i) => <div key={i}>{`[${new Date().toLocaleTimeString()}] ${log}`}</div>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
