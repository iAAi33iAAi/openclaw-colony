import React, { useState, forwardRef, useImperativeHandle } from "react";
import { AGENT_NAMES } from "./SevenAgentInterface";

export interface Task {
  id: string;
  description: string;
  status: 'pending' | 'in-progress' | 'completed';
  assignedAgents: string[];
  timestamp: Date;
}

interface TaskAssignmentPanelProps {
  agentOutputs?: Record<string, any>;
  searchQuery: string;
  tasks: Task[];
  setTasks: React.Dispatch<React.SetStateAction<Task[]>>;
}

export default forwardRef(function TaskAssignmentPanel({ agentOutputs, searchQuery, tasks, setTasks }: TaskAssignmentPanelProps, ref) {
  const [taskDescription, setTaskDescription] = useState("");
  const [selectedAgents, setSelectedAgents] = useState<string[]>([]);
  const [history, setHistory] = useState<Task[]>([]);

  const handleAutoSchedule = () => {
    if (!taskDescription) return;

    // Simulate efficiency: random score for idle agents
    const idleAgents = AGENT_NAMES.filter(name => !agentOutputs?.[name]);
    if (idleAgents.length === 0) {
      alert("No idle agents available.");
      return;
    }

    const agentsWithEfficiency = idleAgents.map(name => ({
      name,
      efficiency: Math.random() * 100
    }));

    // Find highest efficiency
    const bestAgent = agentsWithEfficiency.sort((a, b) => b.efficiency - a.efficiency)[0];

    const newTask: Task = {
      id: Date.now().toString(),
      description: `Auto-scheduled: ${taskDescription}`,
      status: 'pending',
      assignedAgents: [bestAgent.name],
      timestamp: new Date(),
    };
    
    setTasks([...tasks, newTask]);
    setTaskDescription("");
  };

  const handleBroadcast = () => {
    if (!taskDescription || selectedAgents.length === 0) return;
    const newTask: Task = {
      id: Date.now().toString(),
      description: taskDescription,
      status: 'pending',
      assignedAgents: selectedAgents,
      timestamp: new Date(),
    };
    setTasks([...tasks, newTask]);
    setTaskDescription("");
    setSelectedAgents([]);
  };

  useImperativeHandle(ref, () => ({
    handleBroadcast
  }));

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      const rows = text.split('\n').filter(row => row.trim() !== '');
      
      const newTasks: Task[] = rows.map((row, index) => {
        const [description, agentStr] = row.split(',').map(s => s.trim());
        let agents = agentStr ? [agentStr] : AGENT_NAMES;
        if (agentStr === 'All') agents = AGENT_NAMES;
        
        return {
          id: `${Date.now()}-${index}`,
          description,
          status: 'pending',
          assignedAgents: agents,
          timestamp: new Date(),
        };
      });
      setTasks([...tasks, ...newTasks]);
    };
    reader.readAsText(file);
  };

  const completeTask = (id: string) => {
    const task = tasks.find(t => t.id === id);
    if (!task) return;
    setTasks(tasks.filter(t => t.id !== id));
    setHistory([...history, { ...task, status: 'completed' }]);
  };

  const toggleAgent = (agent: string) => {
    setSelectedAgents(prev => 
      prev.includes(agent) ? prev.filter(a => a !== agent) : [...prev, agent]
    );
  };

  return (
    <div className="p-6 bg-slate-900 rounded-xl border border-slate-700 shadow-lg mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
      <div className="flex flex-col gap-4">
        <h2 className="text-xl font-bold text-white mb-2">Task Assignment Panel</h2>
        <input 
          type="text" 
          value={taskDescription}
          onChange={(e) => setTaskDescription(e.target.value)}
          placeholder="Enter task description..."
          className="p-2 bg-slate-800 text-white rounded border border-slate-700"
        />
        <div className="flex flex-wrap gap-2">
          {AGENT_NAMES.map(agent => (
            <button 
              key={agent}
              onClick={() => toggleAgent(agent)}
              className={`px-3 py-1 text-xs rounded-full border ${selectedAgents.includes(agent) ? 'bg-indigo-600 border-indigo-400' : 'bg-slate-800 border-slate-700'} text-white`}
            >
              {agent}
            </button>
          ))}
        </div>
        <div className="flex gap-2">
          <button 
            onClick={handleBroadcast}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded font-semibold"
          >
            Broadcast Task
          </button>
          <button 
            onClick={handleAutoSchedule}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded font-semibold"
          >
            Auto-Schedule
          </button>
          <label className="px-4 py-2 bg-slate-700 hover:bg-slate-600 text-white rounded font-semibold cursor-pointer">
            Bulk Upload (CSV)
            <input type="file" accept=".csv" onChange={handleFileUpload} className="hidden" />
          </label>
        </div>
        <div className="space-y-2">
          <h3 className="text-sm font-semibold text-slate-400">Task Pipeline</h3>
          {tasks.filter(t => t.description.toLowerCase().includes(searchQuery.toLowerCase())).map(task => (
            <div key={task.id} className="p-3 bg-slate-800 rounded border border-slate-700 flex justify-between items-center text-sm">
              <span className="text-slate-200">{task.description}</span>
              <button onClick={() => completeTask(task.id)} className="text-xs bg-emerald-600 hover:bg-emerald-700 px-2 py-1 rounded text-white">Complete</button>
            </div>
          ))}
        </div>
      </div>
      
      <div className="space-y-2">
        <h3 className="text-sm font-semibold text-slate-400">Command History</h3>
        {history.filter(t => t.description.toLowerCase().includes(searchQuery.toLowerCase())).map(task => (
          <div key={task.id} className="p-3 bg-slate-800 rounded border border-slate-700 flex flex-col text-xs text-slate-400">
            <span className="text-slate-200 text-sm">{task.description}</span>
            <div className="flex justify-between mt-1">
              <span>{task.timestamp.toLocaleTimeString()}</span>
              <span className="capitalize">{task.status}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
});
