import React from "react";
import { AGENT_NAMES } from "./SevenAgentInterface";

interface AgentColorConfigProps {
  colors: Record<string, string>;
  onColorChange: (agent: string, color: string) => void;
  onClose: () => void;
}

export default function AgentColorConfig({ colors, onColorChange, onClose }: AgentColorConfigProps) {
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-sm shadow-2xl">
        <h2 className="text-lg font-bold text-white mb-4">Configure Agent Colors</h2>
        <div className="space-y-3">
          {AGENT_NAMES.map(name => (
            <div key={name} className="flex items-center justify-between">
              <span className="text-slate-300">{name}</span>
              <input 
                type="color" 
                value={colors[name]} 
                onChange={(e) => onColorChange(name, e.target.value)}
                className="w-8 h-8 rounded border-none cursor-pointer"
              />
            </div>
          ))}
        </div>
        <button onClick={onClose} className="mt-6 w-full py-2 bg-indigo-600 text-white rounded font-semibold hover:bg-indigo-700">Done</button>
      </div>
    </div>
  );
}
