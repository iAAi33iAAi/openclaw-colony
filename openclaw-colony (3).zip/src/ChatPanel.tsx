import React, { useState, useEffect, useRef } from "react";

interface Message {
  message: string;
  sender: 'user' | 'bot';
}

interface ChatPanelProps {
  onClose: () => void;
}

export default function ChatPanel({ onClose }: ChatPanelProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim()) return;
    const userMsg = { message: input, sender: 'user' as const };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: input, history: messages }),
      });
      const data = await response.json();
      setMessages(prev => [...prev, { message: data.response, sender: 'bot' as const }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { message: "Error talking to colony AI.", sender: 'bot' as const }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center p-4 z-50">
      <div className="bg-slate-900 border border-slate-700 rounded-xl p-6 w-full max-w-lg shadow-2xl flex flex-col h-[60vh]">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-bold text-white">Colony AI Chat</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white">✕</button>
        </div>
        <div className="flex-1 overflow-y-auto space-y-3 mb-4">
          {messages.map((m, i) => (
            <div key={i} className={`p-3 rounded-lg text-sm ${m.sender === 'user' ? 'bg-indigo-900 text-white ml-8' : 'bg-slate-800 text-slate-300 mr-8'}`}>
              {m.message}
            </div>
          ))}
          {loading && <div className="text-slate-500 text-sm">Thinking...</div>}
          <div ref={endRef} />
        </div>
        <div className="flex gap-2">
          <input 
            value={input} 
            onChange={e => setInput(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSend()}
            className="flex-1 bg-slate-800 text-white p-2 rounded border border-slate-700 text-sm"
            placeholder="Ask colony AI..."
          />
          <button onClick={handleSend} className="px-4 py-2 bg-indigo-600 text-white rounded text-sm font-semibold hover:bg-indigo-700">Send</button>
        </div>
      </div>
    </div>
  );
}
