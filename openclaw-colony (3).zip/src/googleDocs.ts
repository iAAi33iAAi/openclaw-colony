import { initializeApp } from "firebase/app";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  User,
} from "firebase/auth";
import firebaseConfig from "../firebase-applet-config.json";

// Initialize Firebase App
const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);

// Configure Google OAuth Provider with correct scopes
const provider = new GoogleAuthProvider();
provider.addScope("https://www.googleapis.com/auth/documents");
provider.addScope("https://www.googleapis.com/auth/documents.readonly");
provider.addScope("https://www.googleapis.com/auth/drive");
provider.addScope("https://www.googleapis.com/auth/drive.file");
provider.addScope("https://www.googleapis.com/auth/drive.readonly");

// In-memory token storage (Do not persist to localStorage for security)
let cachedAccessToken: string | null = null;
let isSigningIn = false;

// Initialize the Auth listener
export const initAuth = (
  onAuthSuccess?: (user: User, token: string) => void,
  onAuthFailure?: () => void
) => {
  return onAuthStateChanged(auth, async (user: User | null) => {
    if (user) {
      if (cachedAccessToken) {
        if (onAuthSuccess) onAuthSuccess(user, cachedAccessToken);
      } else if (!isSigningIn) {
        // If we have a user but no cached token, we can't make API requests yet
        // In this case, we prompt for login or wait
        if (onAuthFailure) onAuthFailure();
      }
    } else {
      cachedAccessToken = null;
      if (onAuthFailure) onAuthFailure();
    }
  });
};

// Google Sign-In with Popup
export const googleSignIn = async (): Promise<{ user: User; accessToken: string } | null> => {
  try {
    isSigningIn = true;
    const result = await signInWithPopup(auth, provider);
    const credential = GoogleAuthProvider.credentialFromResult(result);
    if (!credential?.accessToken) {
      throw new Error("Failed to retrieve Google Access Token from Firebase Auth credentials.");
    }
    cachedAccessToken = credential.accessToken;
    return { user: result.user, accessToken: cachedAccessToken };
  } catch (error) {
    console.error("Sign-In error:", error);
    throw error;
  } finally {
    isSigningIn = false;
  }
};

// Log Out
export const logout = async () => {
  await auth.signOut();
  cachedAccessToken = null;
};

export const getAccessToken = (): string | null => {
  return cachedAccessToken;
};

// ── Google Drive API Helpers ────────────────────────────────────────────────

export interface GoogleDocFile {
  id: string;
  name: string;
  mimeType: string;
  modifiedTime: string;
}

// Lists Google Docs files in user's Drive
export const fetchGoogleDocs = async (accessToken: string): Promise<GoogleDocFile[]> => {
  const query = encodeURIComponent("mimeType='application/vnd.google-apps.document' and trashed=false");
  const url = `https://www.googleapis.com/drive/v3/files?q=${query}&fields=files(id,name,mimeType,modifiedTime)&orderBy=modifiedTime desc&pageSize=30`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    throw new Error(`Failed to list Google Docs files: ${res.statusText}`);
  }

  const data = await res.json();
  return data.files || [];
};

// ── Google Docs API Helpers ─────────────────────────────────────────────────

// Parses a Google Doc structure to extract plain text
const parseDocBody = (body: any): string => {
  if (!body || !body.content) return "";
  let text = "";

  body.content.forEach((element: any) => {
    if (element.paragraph) {
      element.paragraph.elements.forEach((el: any) => {
        if (el.textRun && el.textRun.content) {
          text += el.textRun.content;
        }
      });
    } else if (element.table) {
      element.table.tableRows.forEach((row: any) => {
        row.tableCells.forEach((cell: any) => {
          text += parseDocBody({ content: cell.content }) + "\t";
        });
        text += "\n";
      });
    }
  });

  return text;
};

// Gets plain text content of a Google Doc
export const getGoogleDocContent = async (
  accessToken: string,
  documentId: string
): Promise<{ title: string; text: string }> => {
  const url = `https://docs.googleapis.com/v1/documents/${documentId}`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!res.ok) {
    throw new Error(`Failed to fetch Google Doc content: ${res.statusText}`);
  }

  const doc = await res.json();
  return {
    title: doc.title || "Untitled Doc",
    text: parseDocBody(doc.body),
  };
};

// Exports evaluated reports/tasks to Google Docs
export const exportToGoogleDoc = async (
  accessToken: string,
  title: string,
  markdownContent: string
): Promise<string> => {
  // 1. Create a blank Google Document
  const createUrl = "https://docs.googleapis.com/v1/documents";
  const createRes = await fetch(createUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ title }),
  });

  if (!createRes.ok) {
    throw new Error(`Failed to create Google Doc: ${createRes.statusText}`);
  }

  const doc = await createRes.json();
  const documentId = doc.documentId;

  // 2. Insert text content using batchUpdate
  const updateUrl = `https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`;
  const updateRes = await fetch(updateUrl, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      requests: [
        {
          insertText: {
            text: markdownContent,
            location: { index: 1 },
          },
        },
      ],
    }),
  });

  if (!updateRes.ok) {
    throw new Error(`Failed to populate Google Doc content: ${updateRes.statusText}`);
  }

  return documentId;
};
