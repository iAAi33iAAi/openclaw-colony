interface LQDimension {
  name: string;
  weight: number;
  raw_score: number;
  weighted_score: number;
  rationale: string;
}

interface LQScore {
  composite: number;
  passed: boolean;
  threshold: number;
  rejection_reason: string | null;
  dimensions: LQDimension[];
}

export default function LoveQualityChecker({ lqScore }: { lqScore: LQScore }) {
  return (
    <div className="p-4 bg-slate-800 rounded">
      <h3 className="text-lg font-bold">Love Quality Checker</h3>
      <p>Score: {lqScore.composite}</p>
      <p>Passed: {lqScore.passed ? "Yes" : "No"}</p>
    </div>
  );
}
