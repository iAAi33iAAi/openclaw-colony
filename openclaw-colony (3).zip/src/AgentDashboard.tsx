import React, { useState, useEffect, useRef } from "react";
import { AGENT_NAMES, AGENT_COLORS as DEFAULT_AGENT_COLORS } from "./SevenAgentInterface";
import WorkloadChart from "./WorkloadChart";
import AgentDetailView from "./AgentDetailView";
import AgentColorConfig from "./AgentColorConfig";
import AgentRoleConfig from "./AgentRoleConfig";
import AgentSummaryReport from "./AgentSummaryReport";
import AgentSummaryHeader from "./AgentSummaryHeader";
import { playAudioCue } from "./audioSystem";

interface AgentOutput {
  agent: string;
  domain: string;
  summary: string;
  flags: string[];
  [key: string]: unknown;
}

interface AgentDashboardProps {
  agentOutputs?: Record<string, AgentOutput>;
  loading: boolean;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  searchRef?: React.RefObject<HTMLInputElement>;
  agentRoles: Record<string, string>;
  setAgentRoles: (roles: Record<string, string>) => void;
}

export default function AgentDashboard({ agentOutputs, loading, searchQuery, setSearchQuery, searchRef, agentRoles, setAgentRoles }: AgentDashboardProps) {
  const [selectedAgent, setSelectedAgent] = useState<string | null>(null);
  const [agentColors, setAgentColors] = useState(DEFAULT_AGENT_COLORS);
  const [showConfig, setShowConfig] = useState(false);
  const [showRoleConfig, setShowRoleConfig] = useState(false);
  const [filter, setFilter] = useState<string>("All");
  const [showReport, setShowReport] = useState(false);
  const prevStatuses = useRef<Record<string, string>>({});

  useEffect(() => {
    AGENT_NAMES.forEach(name => {
      const output = agentOutputs?.[name];
      const isOperational = !!output;
      const status = !isOperational ? "Idle" : output.flags.length > 0 ? "Critical" : "Active";
      
      if (prevStatuses.current[name] && prevStatuses.current[name] !== status) {
        playAudioCue(status as 'Active' | 'Critical' | 'Idle');
      }
      prevStatuses.current[name] = status;
    });
  }, [agentOutputs]);

  const handleColorChange = (agent: string, color: string) => {
    setAgentColors(prev => ({ ...prev, [agent]: color }));
  };

  return (
    <div className="p-6 bg-slate-900 rounded-xl border border-slate-700 shadow-lg">
      <AgentSummaryHeader agentOutputs={agentOutputs} />
      <div className="flex flex-col gap-4 mb-4">
        <div className="flex justify-between items-center">
          <h2 className="text-xl font-bold text-white">Colony Agent Status</h2>
          <div className="flex gap-2">
            {["All", "Active", "Critical", "Idle"].map((f) => (
              <button 
                key={f}
                onClick={() => setFilter(f)}
                className={`px-3 py-1 text-xs rounded border ${filter === f ? 'bg-indigo-600 border-indigo-500 text-white' : 'bg-slate-800 border-slate-700 text-slate-300'}`}
              >
                {f}
              </button>
            ))}
            <button 
              onClick={() => setShowConfig(true)}
              className="px-3 py-1 bg-slate-800 text-xs text-slate-300 rounded border border-slate-700 hover:text-white"
            >
              Configure Colors
            </button>
            <button 
              onClick={() => setShowRoleConfig(true)}
              className="px-3 py-1 bg-slate-800 text-xs text-slate-300 rounded border border-slate-700 hover:text-white"
            >
              Configure Roles
            </button>
            <button 
              onClick={() => setShowReport(true)}
              className="px-3 py-1 bg-indigo-800 text-xs text-white rounded border border-indigo-700 hover:bg-indigo-900"
            >
              Weekly Report
            </button>
          </div>
        </div>
        <input 
          type="text"
          ref={searchRef}
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="Search agents, tasks, or logs..."
          className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded text-sm text-white placeholder-slate-400"
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {AGENT_NAMES.filter(name => {
          const output = agentOutputs?.[name];
          const isOperational = !!output;
          const status = !isOperational ? "Idle" : output.flags.length > 0 ? "Critical" : "Active";
          
          const matchesFilter = filter === "All" || status === filter;
          const matchesSearch = name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                                output?.summary.toLowerCase().includes(searchQuery.toLowerCase());
          
          return matchesFilter && matchesSearch;
        }).map((name) => {
          const output = agentOutputs?.[name];
          const isOperational = !!output;
          const healthStatus = !isOperational ? "Idle" : output.flags.length > 0 ? "Warning" : "Healthy";
          const isCritical = healthStatus === 'Warning';
          
          return (
            <div 
              key={name} 
              onClick={() => setSelectedAgent(name)}
              className={`p-4 rounded-lg bg-slate-800 border ${
                !output ? 'border-green-500' : output.flags.length > 0 ? 'border-red-500' : 'border-yellow-500'
              } animate-pulse flex flex-col gap-2 cursor-pointer hover:border-indigo-500 transition-colors`}
            >
              <div className="flex items-center gap-2">
                <div style={{ width: 10, height: 10, borderRadius: '50%', backgroundColor: isOperational ? (healthStatus === 'Healthy' ? '#22c55e' : '#f59e0b') : agentColors[name] || '#64748b' }}></div>
                <span className="font-semibold text-slate-200">{name} Agent</span>
              </div>
              <span className="text-xs text-slate-400">Status: {loading ? "Processing..." : healthStatus}</span>
              {output && <p className="text-xs text-slate-300 line-clamp-2">{output.summary}</p>}
            </div>
          );
        })}
      </div>
      <WorkloadChart />
      {selectedAgent && <AgentDetailView agentName={selectedAgent} onClose={() => setSelectedAgent(null)} color={agentColors[selectedAgent]} searchQuery={searchQuery} />}
      {showConfig && <AgentColorConfig colors={agentColors} onColorChange={handleColorChange} onClose={() => setShowConfig(false)} />}
      {showRoleConfig && <AgentRoleConfig roles={agentRoles} onRoleChange={(agent, role) => setAgentRoles({ ...agentRoles, [agent]: role })} onClose={() => setShowRoleConfig(false)} />}
      {showReport && <AgentSummaryReport onClose={() => setShowReport(false)} />}
    </div>
  );
}
