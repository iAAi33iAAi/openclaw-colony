import React from "react";
import { AGENT_NAMES } from "./SevenAgentInterface";

interface AgentSummaryReportProps {
  onClose: () => void;
}

export default function AgentSummaryReport({ onClose }: AgentSummaryReportProps) {
  // Mock summary data
  const reportData = {
    topAgents: [
      { name: "Atlas", score: 98 },
      { name: "Beacon", score: 95 },
      { name: "Cipher", score: 92 },
    ],
    bottlenecks: ["Data Integration Layer", "Legacy API Sync"],
    period: "July 8 - July 15, 2026",
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50">
      <div className="bg-white text-slate-900 rounded shadow-2xl p-8 w-full max-w-2xl h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6 border-b pb-4">
          <h2 className="text-2xl font-serif font-bold">Weekly Productivity Report</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-slate-800">Close</button>
        </div>
        
        <div className="space-y-6">
          <p className="text-sm text-slate-500">Period: {reportData.period}</p>
          
          <div>
            <h3 className="text-lg font-bold mb-3 border-b pb-1">Top Performing Agents</h3>
            <ul className="space-y-2">
              {reportData.topAgents.map((agent, i) => (
                <li key={i} className="flex justify-between font-mono bg-slate-100 p-2 rounded">
                  <span>{agent.name}</span>
                  <span className="font-bold">{agent.score}% Efficiency</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-3 border-b pb-1">Potential Bottlenecks</h3>
            <ul className="list-disc list-inside text-slate-700">
              {reportData.bottlenecks.map((item, i) => <li key={i}>{item}</li>)}
            </ul>
          </div>
        </div>

        <button 
          onClick={() => window.print()}
          className="mt-8 w-full py-3 bg-slate-900 text-white rounded font-bold hover:bg-slate-800"
        >
          Print Report (PDF)
        </button>
      </div>
    </div>
  );
}
