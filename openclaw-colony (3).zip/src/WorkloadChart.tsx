import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Mock data for the last 24 hours
const data = Array.from({ length: 24 }, (_, i) => ({
  time: `${i}:00`,
  efficiency: Math.floor(Math.random() * 40) + 60,
}));

export default function WorkloadChart() {
  return (
    <div className="h-64 w-full mt-6 bg-slate-800 p-4 rounded-lg border border-slate-700">
      <h3 className="text-sm font-semibold text-slate-300 mb-4">Agent Workload Efficiency (24h)</h3>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis dataKey="time" stroke="#94a3b8" fontSize={12} />
          <YAxis stroke="#94a3b8" fontSize={12} />
          <Tooltip contentStyle={{ backgroundColor: '#1e293b', border: 'none' }} />
          <Line type="monotone" dataKey="efficiency" stroke="#6366f1" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
