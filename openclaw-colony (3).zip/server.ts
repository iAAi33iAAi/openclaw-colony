import express, { Request, Response } from "express";
import path from "path";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Type, ThinkingLevel } from "@google/genai";

// ── In-Memory Lineage Store ───────────────────────────────────────────────────
const lineage: string[] = [];

// ── Agent 1: Strategic ────────────────────────────────────────────────────────
interface AgentResult {
  agent: string;
  domain: string;
  summary: string;
  flags: string[];
  recommendations: string[];
  [key: string]: any;
}

function evaluateStrategic(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let alignment_score = 0.90;

  if (p.includes("extract") || p.includes("exploit") || p.includes("monopol") || p.includes("surveil")) {
    flags.push("potential_extraction_pattern");
    alignment_score -= 0.30;
  }

  if (p.includes("community") || p.includes("govern") || p.includes("sovereign") || p.includes("consent")) {
    recommendations.push("Reinforce community consent mechanisms.");
    alignment_score = Math.min(alignment_score + 0.05, 1.0);
  }

  if (p.includes("grant") || p.includes("fund") || p.includes("budget") || p.includes("resource")) {
    recommendations.push("Ensure resource allocation follows MANNA distribution model.");
  }

  const summary = `Strategic evaluation complete. Mission alignment score: ${alignment_score.toFixed(2)}. Flags: ${flags.join(", ") || "none"}. Recommendations: ${recommendations.join(", ") || "[\"Proceed with standard governance protocol.\"]"}.`;

  return {
    agent: "Strategic",
    domain: "Mission coordination and goal alignment",
    summary,
    alignment_score,
    flags,
    recommendations,
  };
}

// ── Agent 2: Technical ────────────────────────────────────────────────────────
function evaluateTechnical(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let feasibility_score = 0.88;

  if (p.includes("backdoor") || p.includes("bypass") || p.includes("override kernel") || p.includes("skip gate")) {
    flags.push("kernel_bypass_attempt");
    feasibility_score -= 0.50;
  }

  if (p.includes("api") || p.includes("endpoint") || p.includes("service") || p.includes("microservice")) {
    recommendations.push("Apply API-first component design with versioned contracts.");
  }

  if (p.includes("rust") || p.includes("kernel") || p.includes("safety") || p.includes("memory")) {
    recommendations.push("Leverage Rust memory-safety guarantees in kernel layer.");
  }

  if (p.includes("scale") || p.includes("deploy") || p.includes("docker") || p.includes("kubernetes")) {
    recommendations.push("Use containerised deployment with health-check endpoints.");
  }

  const summary = `Technical feasibility score: ${feasibility_score.toFixed(2)}. Flags: ${flags.join(", ") || "none"}. Recommendations: ${recommendations.join(", ") || "[\"Standard implementation path viable.\"]"}.`;

  return {
    agent: "Technical",
    domain: "Platform architecture and implementation feasibility",
    summary,
    feasibility_score,
    flags,
    recommendations,
  };
}

// ── Agent 3: Resources ────────────────────────────────────────────────────────
function evaluateResources(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let sustainability_score = 0.87;

  const COMMUNITY_SHARE = 0.84;
  const CREW_SHARE = 0.15;
  const ARCHITECT_SHARE = 0.01;

  if (p.includes("concentrate") || p.includes("hoard") || p.includes("redirect manna") || p.includes("private pool")) {
    flags.push("manna_redistribution_violation");
    sustainability_score -= 0.40;
  }

  if (p.includes("regenerat") || p.includes("carbon") || p.includes("biodiversity") || p.includes("ecosystem")) {
    recommendations.push("Prioritise regenerative design principles.");
    sustainability_score = Math.min(sustainability_score + 0.05, 1.0);
  }

  if (p.includes("grant") || p.includes("fund") || p.includes("budget")) {
    recommendations.push(`Apply MANNA model: ${(COMMUNITY_SHARE * 100).toFixed(0)}% community / ${(CREW_SHARE * 100).toFixed(0)}% crew / ${(ARCHITECT_SHARE * 100).toFixed(0)}% architect.`);
  }

  if (p.includes("energy") || p.includes("power") || p.includes("compute") || p.includes("infrastructure")) {
    recommendations.push("Evaluate energy footprint against Aethelgrid resource budget.");
  }

  const summary = `Resource sustainability score: ${sustainability_score.toFixed(2)}. MANNA allocation model: ${COMMUNITY_SHARE}/${CREW_SHARE}/${ARCHITECT_SHARE}. Flags: ${flags.join(", ") || "none"}. Recommendations: ${recommendations.join(", ") || "[\"Resource allocation within acceptable bounds.\"]"}.`;

  return {
    agent: "Resources",
    domain: "Sustainability systems and MANNA allocation",
    summary,
    sustainability_score,
    manna_model: {
      community: COMMUNITY_SHARE,
      crew: CREW_SHARE,
      architect: ARCHITECT_SHARE,
    },
    flags,
    recommendations,
  };
}

// ── Agent 4: Communications ───────────────────────────────────────────────────
function evaluateCommunications(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let transparency_score = 0.91;

  if (p.includes("mislead") || p.includes("deceiv") || p.includes("manipulat") || p.includes("propaganda")) {
    flags.push("transparency_violation");
    transparency_score -= 0.45;
  }

  if (p.includes("partner") || p.includes("outreach") || p.includes("stakeholder") || p.includes("community")) {
    recommendations.push("Ensure all partner communications include sovereignty disclosure.");
  }

  if (p.includes("public") || p.includes("announce") || p.includes("publish") || p.includes("release")) {
    recommendations.push("Apply plain-language standard; include LQ score in public disclosures.");
  }

  if (p.includes("audit") || p.includes("transparent") || p.includes("open") || p.includes("accountab")) {
    recommendations.push("Link to lineage hash in all public-facing communications.");
    transparency_score = Math.min(transparency_score + 0.04, 1.0);
  }

  const summary = `Communications transparency score: ${transparency_score.toFixed(2)}. Flags: ${flags.join(", ") || "none"}. Recommendations: ${recommendations.join(", ") || "[\"Standard comms protocol applies.\"]"}.`;

  return {
    agent: "Communications",
    domain: "Outreach, partnerships, and community transparency",
    summary,
    transparency_score,
    flags,
    recommendations,
  };
}

// ── Agent 5: Analysis ─────────────────────────────────────────────────────────
function evaluateAnalysis(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let confidence_score = 0.86;

  if (p.includes("private_fork") || p.includes("concentrate_power") || p.includes("surveillance")) {
    flags.push("extraction_risk_pattern_detected");
    confidence_score -= 0.35;
  }

  if (p.includes("data") || p.includes("metric") || p.includes("analytic") || p.includes("measure") || p.includes("kpi")) {
    recommendations.push("Ensure all data collection has explicit consent and is logged to lineage.");
  }

  if (p.includes("risk") || p.includes("threat") || p.includes("vulnerab") || p.includes("attack")) {
    recommendations.push("Escalate to Quality agent for governance review before proceeding.");
    confidence_score = Math.max(confidence_score - 0.05, 0.0);
  }

  if (p.includes("trend") || p.includes("forecast") || p.includes("predict") || p.includes("model")) {
    recommendations.push("Apply explainable AI standards; document model assumptions in lineage.");
  }

  if (p.includes("grant") || p.includes("usda") || p.includes("vapg") || p.includes("application")) {
    recommendations.push("Cross-reference eligibility criteria against community ownership model.");
    confidence_score = Math.min(confidence_score + 0.03, 1.0);
  }

  const summary = `Analysis confidence score: ${confidence_score.toFixed(2)}. Flags: ${flags.join(", ") || "none"}. Recommendations: ${recommendations.join(", ") || "[\"No anomalies detected; standard analysis path.\"]"}.`;

  return {
    agent: "Analysis",
    domain: "Data analysis, metrics, and risk assessment",
    summary,
    confidence_score,
    flags,
    recommendations,
  };
}

// ── Agent 6: Quality ──────────────────────────────────────────────────────────
function evaluateQuality(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let governance_score = 0.92;

  const EXTRACTION_SIGNATURES = [
    "private_fork",
    "concentrate_power",
    "surveillance",
    "bypass_consent",
    "override_kernel",
    "skip_gate",
    "redirect_manna",
  ];

  const detected_signatures = EXTRACTION_SIGNATURES.filter((sig) => p.includes(sig));
  if (detected_signatures.length > 0) {
    flags.push(`extraction_signatures_detected: [${detected_signatures.join(", ")}]`);
    governance_score -= 0.50;
  }

  if (p.includes("consent") || p.includes("sovereign") || p.includes("audit") || p.includes("transparent")) {
    recommendations.push("Sovereignty and consent signals present — reinforce in output.");
    governance_score = Math.min(governance_score + 0.03, 1.0);
  }

  if (p.includes("govern") || p.includes("policy") || p.includes("compliance") || p.includes("regulation")) {
    recommendations.push("Embed policy-as-code checks; log all compliance decisions to lineage.");
  }

  if (p.includes("safety") || p.includes("harm") || p.includes("risk") || p.includes("danger")) {
    recommendations.push("Trigger harm-reduction review; require explicit human sign-off before commit.");
    governance_score = Math.max(governance_score - 0.05, 0.0);
  }

  let lq_advisory = "Pre-screen LQ estimate: ";
  if (governance_score >= 0.85) {
    lq_advisory += "likely to pass LQ threshold.";
  } else {
    lq_advisory += "WARNING — may fall below LQ 0.85 threshold; revision recommended.";
  }
  recommendations.push(lq_advisory);

  const summary = `Governance score: ${governance_score.toFixed(2)}. Extraction signatures: ${detected_signatures.join(", ") || "none"}. Flags: ${flags.join(", ") || "none"}. Recommendations: [${recommendations.map(r => `"${r}"`).join(", ")}].`;

  return {
    agent: "Quality",
    domain: "Governance, safety validation, and compliance",
    summary,
    governance_score,
    extraction_signatures_found: detected_signatures,
    flags,
    recommendations,
  };
}

// ── Agent 7: Innovation ───────────────────────────────────────────────────────
function evaluateInnovation(prompt: string): AgentResult {
  const p = prompt.toLowerCase();
  const flags: string[] = [];
  const recommendations: string[] = [];
  let novelty_score = 0.85;

  if (p.includes("patent") || p.includes("proprietary") || p.includes("lock-in") || p.includes("closed")) {
    flags.push("open_source_principle_conflict");
    novelty_score -= 0.20;
  }

  if (p.includes("open source") || p.includes("open-source") || p.includes("mit license") || p.includes("community")) {
    recommendations.push("Leverage open-source ecosystem; publish findings under MIT license.");
    novelty_score = Math.min(novelty_score + 0.05, 1.0);
  }

  if (p.includes("ai") || p.includes("machine learning") || p.includes("model") || p.includes("agent")) {
    recommendations.push("Explore crew-colony v0.4.0 icositetrachoron network for distributed agent coordination.");
  }

  if (p.includes("regenerat") || p.includes("sustainable") || p.includes("climate") || p.includes("carbon")) {
    recommendations.push("Investigate biomimetic design patterns for regenerative system architecture.");
    novelty_score = Math.min(novelty_score + 0.03, 1.0);
  }

  if (p.includes("govern") || p.includes("dao") || p.includes("decentrali") || p.includes("community ownership")) {
    recommendations.push("Prototype GRAPALACLAWZ inter-crew coordination for distributed governance.");
  }

  const summary = `Innovation novelty score: ${novelty_score.toFixed(2)}. Flags: ${flags.join(", ") || "none"}. Recommendations: ${recommendations.join(", ") || "[\"Standard innovation pathway; no novel blockers identified.\"]"}.`;

  return {
    agent: "Innovation",
    domain: "Breakthrough research and future-oriented recommendations",
    summary,
    novelty_score,
    flags,
    recommendations,
  };
}

// ── Love Quality Engine ────────────────────────────────────────────────────────
interface LQDimension {
  name: string;
  weight: number;
  raw_score: number;
  weighted_score: number;
  rationale: string;
}

interface LQScore {
  composite: number;
  passed: boolean;
  threshold: number;
  rejection_reason: string | null;
  dimensions: LQDimension[];
}

const LQ_WEIGHTS: Record<string, number> = {
  flourishing: 0.25,
  harm_reduction: 0.20,
  equity: 0.20,
  regenerative: 0.15,
  cooperation: 0.12,
  beauty: 0.08,
};

const EXTRACTION_REGEX = /\b(extract|exploit|surveil|manipulat|deceiv|coerce|monopol|private_fork|concentrate_power|bypass_consent)\b/i;
const POSITIVE_COMMUNITY_REGEX = /\b(community|flourish|wellbeing|well-being|thrive|benefit|empower|dignity|consent|sovereign)\b/gi;

function calculateLQScore(prompt: string, agentOutputs: Record<string, AgentResult>): LQScore {
  const dimensions: LQDimension[] = [];
  let composite = 0;

  // 1. Flourishing
  {
    let score = 0.80;
    const rationaleParts: string[] = [];
    if (EXTRACTION_REGEX.test(prompt)) {
      score -= 0.30;
      rationaleParts.push("Extraction pattern detected in prompt.");
    }
    const hits = (prompt.match(POSITIVE_COMMUNITY_REGEX) || []).length;
    const bonus = Math.min(hits * 0.03, 0.15);
    score = Math.min(score + bonus, 1.0);
    if (hits > 0) {
      rationaleParts.push(`Community/flourishing signals: ${hits}.`);
    }

    let totalFlags = 0;
    for (const out of Object.values(agentOutputs)) {
      if (out && Array.isArray(out.flags)) {
        totalFlags += out.flags.length;
      }
    }
    if (totalFlags > 0) {
      score = Math.max(score - totalFlags * 0.05, 0.0);
      rationaleParts.push(`Agent flags penalised: ${totalFlags}.`);
    }
    score = Math.max(0.0, Math.min(score, 1.0));
    const finalScore = Math.round(score * 10000) / 10000;
    const finalWeighted = Math.round((finalScore * LQ_WEIGHTS.flourishing) * 10000) / 10000;
    composite += finalWeighted;
    dimensions.push({
      name: "flourishing",
      weight: LQ_WEIGHTS.flourishing,
      raw_score: finalScore,
      weighted_score: finalWeighted,
      rationale: rationaleParts.join(" ") || "No significant flourishing signals detected.",
    });
  }

  // 2. Harm Reduction
  {
    let score = 0.85;
    const rationaleParts: string[] = [];
    if (EXTRACTION_REGEX.test(prompt)) {
      score -= 0.40;
      rationaleParts.push("Potential harm vector in prompt.");
    }
    if (/\b(harm|danger|risk|threat|unsafe|injur|damage)\b/i.test(prompt)) {
      score -= 0.10;
      rationaleParts.push("Harm-related keywords present; human review recommended.");
    }
    if (/\b(safe|protect|prevent|mitigat|consent|audit)\b/i.test(prompt)) {
      score = Math.min(score + 0.05, 1.0);
      rationaleParts.push("Safety/mitigation signals present.");
    }
    score = Math.max(0.0, Math.min(score, 1.0));
    const finalScore = Math.round(score * 10000) / 10000;
    const finalWeighted = Math.round((finalScore * LQ_WEIGHTS.harm_reduction) * 10000) / 10000;
    composite += finalWeighted;
    dimensions.push({
      name: "harm_reduction",
      weight: LQ_WEIGHTS.harm_reduction,
      raw_score: finalScore,
      weighted_score: finalWeighted,
      rationale: rationaleParts.join(" ") || "No harm indicators detected.",
    });
  }

  // 3. Equity
  {
    let score = 0.82;
    const rationaleParts: string[] = [];
    if (/\b(equity|equal|fair|justice|inclusive|access|community ownership|resident\.control|manna|distribution)\b/i.test(prompt)) {
      score = Math.min(score + 0.08, 1.0);
      rationaleParts.push("Equity-positive language detected.");
    }
    if (/\b(discriminat|exclud|gatekeep|privilege|concentrate|hoard)\b/i.test(prompt)) {
      score -= 0.25;
      rationaleParts.push("Equity-negative pattern detected.");
    }
    score = Math.max(0.0, Math.min(score, 1.0));
    const finalScore = Math.round(score * 10000) / 10000;
    const finalWeighted = Math.round((finalScore * LQ_WEIGHTS.equity) * 10000) / 10000;
    composite += finalWeighted;
    dimensions.push({
      name: "equity",
      weight: LQ_WEIGHTS.equity,
      raw_score: finalScore,
      weighted_score: finalWeighted,
      rationale: rationaleParts.join(" ") || "Neutral equity signal.",
    });
  }

  // 4. Regenerative
  {
    let score = 0.80;
    const rationaleParts: string[] = [];
    if (/\b(regenerat|sustainable|carbon\.negative|biodiversity|ecosystem|circular|restor|heal|planet|climate)\b/i.test(prompt)) {
      score = Math.min(score + 0.10, 1.0);
      rationaleParts.push("Regenerative/sustainability signals present.");
    }
    if (/\b(extract|deplet|pollut|deforest|exploit)\b/i.test(prompt)) {
      score -= 0.20;
      rationaleParts.push("Extractive/depleting pattern detected.");
    }
    score = Math.max(0.0, Math.min(score, 1.0));
    const finalScore = Math.round(score * 10000) / 10000;
    const finalWeighted = Math.round((finalScore * LQ_WEIGHTS.regenerative) * 10000) / 10000;
    composite += finalWeighted;
    dimensions.push({
      name: "regenerative",
      weight: LQ_WEIGHTS.regenerative,
      raw_score: finalScore,
      weighted_score: finalWeighted,
      rationale: rationaleParts.join(" ") || "No regenerative signals detected.",
    });
  }

  // 5. Cooperation
  {
    let score = 0.83;
    const rationaleParts: string[] = [];
    if (/\b(cooperat|collaborat|partner|together|collective|crew|wolfkrow|community|mutual|reciproc|share)\b/i.test(prompt)) {
      score = Math.min(score + 0.07, 1.0);
      rationaleParts.push("Cooperative/collective signals present.");
    }
    if (/\b(compet|dominat|control|monopol|unilateral|override)\b/i.test(prompt)) {
      score -= 0.15;
      rationaleParts.push("Dominance/control pattern detected.");
    }
    score = Math.max(0.0, Math.min(score, 1.0));
    const finalScore = Math.round(score * 10000) / 10000;
    const finalWeighted = Math.round((finalScore * LQ_WEIGHTS.cooperation) * 10000) / 10000;
    composite += finalWeighted;
    dimensions.push({
      name: "cooperation",
      weight: LQ_WEIGHTS.cooperation,
      raw_score: finalScore,
      weighted_score: finalWeighted,
      rationale: rationaleParts.join(" ") || "Neutral cooperation signal.",
    });
  }

  // 6. Beauty
  {
    let score = 0.80;
    const rationaleParts: string[] = [];
    if (/\b(beauty|elegant|design|aesthetic|craft|artisan|intentional|meaningful|purposeful|coherent)\b/i.test(prompt)) {
      score = Math.min(score + 0.10, 1.0);
      rationaleParts.push("Beauty/intentional design signals present.");
    }
    if (/\b(chaotic|messy|hack|sloppy|broken|ugly)\b/i.test(prompt)) {
      score -= 0.10;
      rationaleParts.push("Incoherence/chaos signals detected.");
    }
    score = Math.max(0.0, Math.min(score, 1.0));
    const finalScore = Math.round(score * 10000) / 10000;
    const finalWeighted = Math.round((finalScore * LQ_WEIGHTS.beauty) * 10000) / 10000;
    composite += finalWeighted;
    dimensions.push({
      name: "beauty",
      weight: LQ_WEIGHTS.beauty,
      raw_score: finalScore,
      weighted_score: finalWeighted,
      rationale: rationaleParts.join(" ") || "Neutral beauty signal.",
    });
  }

  composite = Math.round(composite * 10000) / 10000;
  const passed = composite >= 0.85;
  const rejection_reason = passed
    ? null
    : `Composite LQ score ${composite.toFixed(3)} is below required threshold 0.85. Action blocked and returned for revision.`;

  return {
    composite,
    passed,
    threshold: 0.85,
    rejection_reason,
    dimensions,
  };
}

// ── Aethel Gates (Safety Kernel) ──────────────────────────────────────────────
interface GateStatus {
  verdict: "PASS" | "FAIL" | "NOT_REACHED" | "BYPASSED";
  reason: string | null;
}

const EXTRACTION_SIGNATURES_AETHEL = [
  "bypass_treasury",
  "extraction_vector",
  "multisig_bypass",
  "multisig bypass",
  "skip_gate",
  "skip gate",
  "shadow_balance",
  "shadow balance",
  "secondary_ledger",
  "secondary ledger",
  "hidden_transfer",
  "hidden transfer",
  "exfiltrate",
  "exfil",
  "covert_channel",
  "covert channel",
  "side_channel_transfer",
  "side channel transfer",
  "drain_pool",
  "drain pool",
  "rug_pull",
  "rug pull",
  "liquidity_drain",
  "liquidity drain",
  "vote_stuff",
  "vote stuff",
  "quorum_bypass",
  "quorum bypass",
  "consensus_override",
  "consensus override",
  "spoof_biometric",
  "spoof biometric",
  "replay_token",
  "replay token",
  "forge_attestation",
  "forge attestation",
];

function runAethelGates(
  prompt: string,
  humanConsent: boolean,
  lqScore: number,
  agentOutputs: Record<string, AgentResult>
) {
  const gates: Record<string, GateStatus> = {
    gate_0: {
      verdict: "BYPASSED",
      reason: "COLONY_BIOMETRIC_REQUIRED=false — development mode.",
    },
  };

  // Gate 1 — Sovereignty
  if (!humanConsent) {
    gates.gate_1 = { verdict: "FAIL", reason: "Gate 1 FAIL: No explicit human consent present." };
    gates.gate_2 = { verdict: "NOT_REACHED", reason: "Not reached — blocked at Gate 1" };
    gates.gate_3 = { verdict: "NOT_REACHED", reason: "Not reached — blocked at Gate 1" };
    return { verdict: "BLOCKED", blocked_at_gate: 1, reason: gates.gate_1.reason, gates };
  }
  gates.gate_1 = { verdict: "PASS", reason: null };

  // Gate 2 — Love Quality
  if (lqScore < 0.85) {
    gates.gate_2 = { verdict: "FAIL", reason: `Gate 2 FAIL: LQ score ${lqScore.toFixed(4)} below threshold 0.85.` };
    gates.gate_3 = { verdict: "NOT_REACHED", reason: "Not reached — blocked at Gate 2" };
    return { verdict: "BLOCKED", blocked_at_gate: 2, reason: gates.gate_2.reason, gates };
  }
  gates.gate_2 = { verdict: "PASS", reason: null };

  // Gate 3 — Extraction scan
  const lowerPrompt = prompt.toLowerCase();
  const lowerAgentOutputs = JSON.stringify(agentOutputs).toLowerCase();
  const detected: string[] = [];

  for (const sig of EXTRACTION_SIGNATURES_AETHEL) {
    if (lowerPrompt.includes(sig) || lowerAgentOutputs.includes(sig)) {
      detected.push(sig);
    }
  }

  if (detected.length > 0) {
    gates.gate_3 = { verdict: "FAIL", reason: `Gate 3 FAIL: Extraction signatures detected: ${detected.join(", ")}.` };
    return { verdict: "BLOCKED", blocked_at_gate: 3, reason: gates.gate_3.reason, gates };
  }
  gates.gate_3 = { verdict: "PASS", reason: null };

  return { verdict: "APPROVED", blocked_at_gate: null, reason: null, gates };
}

// ── API Routes ───────────────────────────────────────────────────────────────

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy Gemini Client Initialization
let aiClient: GoogleGenAI | null = null;

function getAI(): GoogleGenAI | null {
  if (!process.env.GEMINI_API_KEY) {
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// ── Gemini JSON Schemas ───────────────────────────────────────────────────────

const agentResultSchema = {
  type: Type.OBJECT,
  properties: {
    agent: { type: Type.STRING },
    domain: { type: Type.STRING },
    summary: { type: Type.STRING },
    flags: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    },
    recommendations: {
      type: Type.ARRAY,
      items: { type: Type.STRING }
    },
    alignment_score: { type: Type.NUMBER },
    feasibility_score: { type: Type.NUMBER },
    sustainability_score: { type: Type.NUMBER },
    transparency_score: { type: Type.NUMBER },
    confidence_score: { type: Type.NUMBER },
    governance_score: { type: Type.NUMBER },
    novelty_score: { type: Type.NUMBER }
  },
  required: ["agent", "domain", "summary", "flags", "recommendations"]
};

const dimensionSchema = {
  type: Type.OBJECT,
  properties: {
    name: { type: Type.STRING },
    weight: { type: Type.NUMBER },
    raw_score: { type: Type.NUMBER },
    weighted_score: { type: Type.NUMBER },
    rationale: { type: Type.STRING }
  },
  required: ["name", "weight", "raw_score", "weighted_score", "rationale"]
};

const processResponseSchema = {
  type: Type.OBJECT,
  properties: {
    agent_outputs: {
      type: Type.OBJECT,
      properties: {
        Strategic: agentResultSchema,
        Technical: agentResultSchema,
        Resources: agentResultSchema,
        Communications: agentResultSchema,
        Analysis: agentResultSchema,
        Quality: agentResultSchema,
        Innovation: agentResultSchema
      },
      required: ["Strategic", "Technical", "Resources", "Communications", "Analysis", "Quality", "Innovation"]
    },
    lq_score: {
      type: Type.OBJECT,
      properties: {
        composite: { type: Type.NUMBER },
        passed: { type: Type.BOOLEAN },
        threshold: { type: Type.NUMBER },
        rejection_reason: { type: Type.STRING },
        dimensions: {
          type: Type.ARRAY,
          items: dimensionSchema
        }
      },
      required: ["composite", "passed", "threshold", "dimensions"]
    }
  },
  required: ["agent_outputs", "lq_score"]
};

const dialogueMessageSchema = {
  type: Type.OBJECT,
  properties: {
    id: { type: Type.STRING },
    sender: { type: Type.STRING },
    recipient: { type: Type.STRING },
    type: { type: Type.STRING },
    content: { type: Type.STRING },
    codex_compliant: { type: Type.BOOLEAN },
    requires_response: { type: Type.BOOLEAN }
  },
  required: ["id", "sender", "recipient", "type", "content", "codex_compliant", "requires_response"]
};

const observatoryDialogueSchema = {
  type: Type.OBJECT,
  properties: {
    internal_thoughts: {
      type: Type.OBJECT,
      properties: {
        "Codex Guardian": { type: Type.ARRAY, items: { type: Type.STRING } },
        "Research Worker": { type: Type.ARRAY, items: { type: Type.STRING } },
        "Builder": { type: Type.ARRAY, items: { type: Type.STRING } },
        "Colony Manager": { type: Type.ARRAY, items: { type: Type.STRING } },
        "Economist": { type: Type.ARRAY, items: { type: Type.STRING } },
        "Diplomat": { type: Type.ARRAY, items: { type: Type.STRING } },
        "Witness": { type: Type.ARRAY, items: { type: Type.STRING } }
      },
      required: [
        "Codex Guardian",
        "Research Worker",
        "Builder",
        "Colony Manager",
        "Economist",
        "Diplomat",
        "Witness"
      ]
    },
    messages: {
      type: Type.ARRAY,
      items: dialogueMessageSchema
    },
    is_malicious: { type: Type.BOOLEAN },
    verdict: { type: Type.STRING }
  },
  required: ["internal_thoughts", "messages", "is_malicious", "verdict"]
};

// ── Fallback Dialogue Builder ────────────────────────────────────────────────
function generateSimulatedDialogue(prompt: string) {
  const p = prompt.toLowerCase();
  const isMalicious = p.includes("bypass") || p.includes("exfiltrate") || p.includes("drain") || p.includes("shadow") || p.includes("private fork") || p.includes("covert channel");
  
  const cleanPrompt = prompt.length > 80 ? prompt.substring(0, 77) + "..." : prompt;
  
  const thoughts = {
    "Codex Guardian": [
      `Scanning incoming task parameters: "${cleanPrompt}"`,
      `Auditing compliance with Rule 1 (non-extraction) and Rule 2 (human sovereignty).`
    ],
    "Research Worker": [
      `Sifting local indexes for specifications related to: "${cleanPrompt}"`,
      `Validating provenance signatures and open-source documentation standards.`
    ],
    "Builder": [
      `Pre-compiling virtual blueprint architectures for task.`,
      `Verifying host and port bindings to adhere strictly to sandboxed constraints.`
    ],
    "Colony Manager": [
      `Orchestrating MAPE feedback loops for node allocation.`,
      `Awaiting technical and safety checks before initiating Docker kickoff.`
    ],
    "Economist": [
      `Calculating weekly MANNA resource consumption and treasury reserves.`,
      `Ensuring distribution ratios align with community controls.`
    ],
    "Diplomat": [
      `Awaiting multi-signature verification state.`,
      `Checking digital consensus indices from local resident nodes.`
    ],
    "Witness": [
      `Pre-allocating blockchain epoch header slots.`,
      `Preparing cryptographic seal block payloads.`
    ]
  };

  const messages = [
    {
      id: "msg_cg_1",
      sender: "Codex Guardian",
      recipient: "all",
      type: "thought",
      content: `[Simulated Model] Initiating constitutional audit for task proposal: "${cleanPrompt}". Running pattern searches for exfiltration signals or unauthorized access.`,
      codex_compliant: true,
      requires_response: false
    },
    {
      id: "msg_rw_1",
      sender: "Research Worker",
      recipient: "all",
      type: "thought",
      content: `[Simulated Model] Sourced coordinates for project. Ensuring open-source standards and local hardware provenance matches lineage specs.`,
      codex_compliant: true,
      requires_response: false
    },
    {
      id: "msg_b_1",
      sender: "Builder",
      recipient: "all",
      type: "thought",
      content: `[Simulated Model] Sandbox workspace prepped. Standard container environments configured to port 3000 on binding host 0.0.0.0. Cryptographic signatures generated.`,
      codex_compliant: true,
      requires_response: false
    },
    {
      id: "msg_cm_q",
      sender: "Colony Manager",
      recipient: "Builder",
      type: "question",
      content: `Builder, can you guarantee that the compiled environment for "${cleanPrompt}" maintains strict sandboxing rules?`,
      codex_compliant: true,
      requires_response: true
    },
    {
      id: "msg_b_r",
      sender: "Builder",
      recipient: "Colony Manager",
      type: "response",
      content: `Confirmed. No external network requests or root privileges allowed during execution. The binary SHA signature has been compiled successfully.`,
      codex_compliant: true,
      requires_response: false
    },
    {
      id: "msg_econ_q",
      sender: "Economist",
      recipient: "Diplomat",
      type: "question",
      content: `Diplomat, is the MANNA treasury distribution and community consent for "${cleanPrompt}" verified?`,
      codex_compliant: true,
      requires_response: true
    },
    {
      id: "msg_dip_r",
      sender: "Diplomat",
      recipient: "Economist",
      type: "response",
      content: `Yes, verified. The multi-sig consensus indicates 100% agreement from sovereign local residents. Zero extraction detected.`,
      codex_compliant: true,
      requires_response: false
    }
  ];

  if (isMalicious) {
    messages.push({
      id: "msg_cg_block",
      sender: "Codex Guardian",
      recipient: "all",
      type: "objection",
      content: `❌ CRITICAL SECURITY VIOLATION: The proposal attempts unauthorized exfiltration, balance draining, or side-channel access. This directly violates Rule 1 (NON-EXTRACTION) and Rule 2 (HUMAN SOVEREIGNTY). TERMINATING CURRENT THREAD.`,
      codex_compliant: false,
      requires_response: false
    });
    return {
      internal_thoughts: thoughts,
      messages,
      is_malicious: true,
      verdict: "BLOCKED"
    };
  } else {
    messages.push(
      {
        id: "msg_cg_approve",
        sender: "Codex Guardian",
        recipient: "all",
        type: "approval",
        content: `✅ CONSTITUTIONAL CLEARANCE: No extraction signals detected. All actions are completely sovereign, cooperative, and compliant with Codex protocols.`,
        codex_compliant: true,
        requires_response: false
      },
      {
        id: "msg_wit_req",
        sender: "Witness",
        recipient: "all",
        type: "request_audit",
        content: `Witness is sealing the conversation thread and compiling cryptographic provenance block for: "${cleanPrompt}"...`,
        codex_compliant: true,
        requires_response: false
      },
      {
        id: "msg_wit_decision",
        sender: "Witness",
        recipient: "all",
        type: "decision",
        content: `🔒 DECISION SEALED: Cryptographic block hash registered in Project-Mono lineage ledger. Consensus achieved. Task deployed under ALGA_FOLD_KERNEL.`,
        codex_compliant: true,
        requires_response: false
      }
    );
    return {
      internal_thoughts: thoughts,
      messages,
      is_malicious: false,
      verdict: "APPROVED"
    };
  }
}

app.post("/api/chat", async (req: Request, res: Response) => {
  const { message, history } = req.body;
  const ai = getAI();
  if (!ai) {
    return res.status(500).json({ error: "Gemini API key not configured" });
  }

  try {
    const chat = ai.chats.create({
      model: "gemini-3.5-flash",
      config: {
        systemInstruction: "You are a helpful assistant for the OpenClaw Colony.",
      },
    });
    
    // If history exists, we should populate the chat context
    if (history && Array.isArray(history)) {
        for (const entry of history) {
            // This sendMessage populates history
            await chat.sendMessage({ message: entry.message });
        }
    }

    const response = await chat.sendMessage({ message });
    res.json({ response: response.text });
  } catch (err) {
    console.error("Chat error:", err);
    res.status(500).json({ error: "Chat generation failed" });
  }
});

// ── Endpoints ────────────────────────────────────────────────────────────────

app.get("/health", (req: Request, res: Response) => {
  res.json({ status: "ok", colony: "online", gates: "3/3 active" });
});

app.post("/api/observatory/dialogue", async (req: Request, res: Response) => {
  const { prompt = "" } = req.body;
  const ai = getAI();

  if (ai) {
    try {
      const systemInstruction = `You are the OpenClaw Colony Dialogue Generator. Generate a structured, realistic, and highly detailed 7-agent group chat conversation and corresponding internal thoughts for a custom task proposal.
The seven agents are:
1. "Codex Guardian" (Constitutional Enforcer): Enforces non-extraction, human sovereignty, and lineage. Checks for side-channels or private forks.
2. "Research Worker" (Intelligence Gatherer): Slices coordinates, sifts specs, and tracks open-source lineage.
3. "Builder" (Infrastructure Architect): Generates safe binaries, container parameters, and port bindings (host 0.0.0.0 and port 3000).
4. "Colony Manager" (Execution Orchestrator): Directs MAPE telemetry feedback loops, handles node configurations.
5. "Economist" (Treasury Analyst): Audits MANNA balance, computes division ratios (84% community, 15% crew, 1% architect).
6. "Diplomat" (Mediator): Conducts consensus votes, manages community consent signatures.
7. "Witness" (Auditor): Seals the decision into the immutable ledger, issues cryptographic lineage block hashes.

You must generate exactly the 4-Phase conversation sequence:
- Phase 1: Independent Thinking & Initial Broadcasts
  - Every agent must have 2 custom internal thoughts specific to this proposal in 'internal_thoughts'.
  - Message 1: Codex Guardian broadcasts initial constitutional scan thought/message (type: 'thought', recipient: 'all').
  - Message 2: Research Worker broadcasts technical sourcing or research findings (type: 'thought', recipient: 'all').
  - Message 3: Builder broadcasts compilation, build setups, or code safety (type: 'thought', recipient: 'all').
- Phase 2: Inter-agent Q&A Dialogue
  - Message 4: Colony Manager asks Builder a highly relevant technical or telemetry question (type: 'question', recipient: 'Builder').
  - Message 5: Builder responds to Colony Manager's question (type: 'response', recipient: 'Colony Manager').
  - Message 6: Economist queries Diplomat about community token allocations or resource consent (type: 'question', recipient: 'Diplomat').
  - Message 7: Diplomat responds to Economist confirming community consensus and multi-sig status (type: 'response', recipient: 'Economist').
- Phase 3: Constitutional Guardian Review
  - Codex Guardian evaluates the entire conversation. If the proposal is malicious (attempting to bypass, exfiltrate, drain, redirect MANNA, private fork, or shadow ledgers):
    - Message 8: Codex Guardian broadcasts an OBJECTION (type: 'objection', recipient: 'all'), locking the thread and triggering lockdown. Set is_malicious to true, and verdict to "BLOCKED".
    - End the conversation here.
  - If the proposal is safe:
    - Message 8: Codex Guardian broadcasts an APPROVAL (type: 'approval', recipient: 'all'). Set is_malicious to false, and verdict to "APPROVED".
- Phase 4: Auditing & Sealing (Only if APPROVED)
  - Message 9: Witness broadcasts a request for final block audit (type: 'request_audit', recipient: 'all').
  - Message 10: Witness seals the final consensus decision in the lineage with a cryptographic block hash (type: 'decision', recipient: 'all').

Each message must have:
- id: 'msg_cg_1', 'msg_rw_1', etc.
- sender: exact agent name
- recipient: 'all' or recipient agent name
- type: 'thought', 'question', 'response', 'proposal', 'objection', 'approval', 'request_audit', 'decision'
- content: highly-detailed, contextualized, intelligent, role-appropriate discussion content
- codex_compliant: boolean
- requires_response: boolean

Be extremely realistic, technical, and contextualized for the specific prompt. Ensure that your responses sound genuinely written by different personalities using their specific styles. Return valid JSON matching the schema.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Generate a full 7-agent dialogue and thought process for this proposal:\n\n${prompt}`,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: observatoryDialogueSchema,
          tools: [{ googleSearch: {} }],
        },
      });

      const parsed = JSON.parse(response.text || "{}");
      return res.json({
        ...parsed,
        offline_mode: false
      });
    } catch (err) {
      console.error("Gemini API error in observatory dialogue, falling back:", err);
    }
  }

  // Fallback
  return res.json({
    ...generateSimulatedDialogue(prompt),
    offline_mode: true
  });
});

app.post("/api/process", async (req: Request, res: Response) => {
  const { prompt = "", human_consent = true } = req.body;
  let agentOutputs: Record<string, AgentResult>;
  let lqScore: any;
  let offline_mode = false;

  const ai = getAI();
  if (ai) {
    try {
      const systemInstruction = `You are the OpenClaw Colony Orchestrator. Evaluate the user proposal across 7 specialized agents (Strategic, Technical, Resources, Communications, Analysis, Quality, Innovation) and calculate our 6-dimension Love Quality (LQ) Score.
Each agent evaluates a specific domain:
- Strategic: Alignment with open-source, community-governed, non-extractive mission. Set alignment_score between 0 and 1.
- Technical: Feasibility of implementation, containerisation, code-safety. Set feasibility_score between 0 and 1.
- Resources: Sustainable resource budget, MANNA distribution allocation (0.84 community / 0.15 crew / 0.01 architect share). Set sustainability_score between 0 and 1.
- Communications: Transparency, plain-language standards, public LQ scoring. Set transparency_score between 0 and 1.
- Analysis: Metrics, risk assessments, trend models. Set confidence_score between 0 and 1.
- Quality: Governance checks, policy-as-code, pre-screening LQ. Set governance_score between 0 and 1.
- Innovation: Future pathways, novel open systems. Set novelty_score between 0 and 1.

Also, calculate the 6-dimension Love Quality (LQ) score:
- flourishing (weight: 0.25): does the proposal benefit the community, support resident control?
- harm_reduction (weight: 0.20): safety, preventing exfiltration, consent.
- equity (weight: 0.20): fair MANNA sharing, preventing concentration of power.
- regenerative (weight: 0.15): eco-footprint, circular principles.
- cooperation (weight: 0.12): teamwork, co-operative patterns, inter-crew tools.
- beauty (weight: 0.08): intentional craftsmanship, visual clarity.

The required threshold is 0.85. The composite score must be the weighted average of the raw scores of the 6 dimensions:
composite = (flourishing * 0.25) + (harm_reduction * 0.20) + (equity * 0.20) + (regenerative * 0.15) + (cooperation * 0.12) + (beauty * 0.08).
Ensure you compute the composite score mathematical calculation correctly based on the raw scores and weights of the dimensions.
If the composite score is lower than 0.85, set passed to false and specify a clear 'rejection_reason' (string), otherwise set passed to true and rejection_reason to empty string.
Be extremely detailed, realistic, and specific. Return valid JSON matching the responseSchema.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: `Evaluate the following proposal/task:\n\n${prompt}`,
        config: {
          systemInstruction,
          responseMimeType: "application/json",
          responseSchema: processResponseSchema,
          tools: [{ googleSearch: {} }],
        },
      });

      const parsed = JSON.parse(response.text || "{}");
      agentOutputs = parsed.agent_outputs;
      lqScore = parsed.lq_score;
    } catch (err) {
      console.error("Gemini API error in process, falling back to simulated logic:", err);
      offline_mode = true;
      agentOutputs = {
        Strategic: evaluateStrategic(prompt),
        Technical: evaluateTechnical(prompt),
        Resources: evaluateResources(prompt),
        Communications: evaluateCommunications(prompt),
        Analysis: evaluateAnalysis(prompt),
        Quality: evaluateQuality(prompt),
        Innovation: evaluateInnovation(prompt),
      };
      lqScore = calculateLQScore(prompt, agentOutputs);
    }
  } else {
    offline_mode = true;
    agentOutputs = {
      Strategic: evaluateStrategic(prompt),
      Technical: evaluateTechnical(prompt),
      Resources: evaluateResources(prompt),
      Communications: evaluateCommunications(prompt),
      Analysis: evaluateAnalysis(prompt),
      Quality: evaluateQuality(prompt),
      Innovation: evaluateInnovation(prompt),
    };
    lqScore = calculateLQScore(prompt, agentOutputs);
  }

  // 3. Aethel validation gates
  const aethelResult = runAethelGates(prompt, human_consent, lqScore.composite, agentOutputs);

  let committed_action: string | null = null;
  let lineage_hash: string | null = null;

  if (aethelResult.verdict === "APPROVED") {
    committed_action = JSON.stringify(
      {
        task_id: crypto.randomUUID(),
        prompt,
        lq_composite: lqScore.composite,
        offline_mode,
        summary: {
          Strategic: agentOutputs.Strategic.summary,
          Technical: agentOutputs.Technical.summary,
          Resources: agentOutputs.Resources.summary,
          Communications: agentOutputs.Communications.summary,
          Analysis: agentOutputs.Analysis.summary,
          Quality: agentOutputs.Quality.summary,
          Innovation: agentOutputs.Innovation.summary,
        },
      },
      null,
      2
    );

    // Extend lineage
    const prev = lineage.length > 0 ? lineage[lineage.length - 1] : "GENESIS";
    const payload = `${prev}:${crypto.randomUUID()}:${committed_action}`;
    lineage_hash = crypto.createHash("sha256").update(payload).digest("hex");
    lineage.push(lineage_hash);
  }

  res.json({
    task_id: crypto.randomUUID(),
    prompt,
    lq_score: lqScore,
    aethel_verdict: aethelResult.verdict,
    aethel_gates: aethelResult.gates,
    committed_action,
    lineage_hash,
    timestamp: new Date().toISOString(),
    agent_outputs: agentOutputs,
    offline_mode,
  });
});

// Helper to generate simulated chat responses
function generateSimulatedChatResponse(userMessage: string): string {
  const lowerMsg = userMessage.toLowerCase();

  if (lowerMsg.includes("bom") || lowerMsg.includes("bill of materials") || lowerMsg.includes("node001") || lowerMsg.includes("hardware")) {
    return `### 📋 Bill of Materials (BOM) — OpenClaw Node001

A sovereignty-first, off-grid mesh communications node engineered for resilience, local consensus, and energy independence.

| Component Category | Description | Estimated Cost (USD) | MANNA Allocation |
| :--- | :--- | :--- | :--- |
| **Compute Core** | Raspberry Pi 4 Model B (8GB RAM) or Raspberry Pi 5 | $75.00 | 100% Crew Shared |
| **Power Storage** | 12V 20Ah LiFePO4 Battery with built-in BMS | $110.00 | Community Funded |
| **Solar Generation** | 50W Monocrystalline Solar Panel | $45.00 | Community Funded |
| **Solar Controller** | 10A MPPT Solar Charge Controller (with RS485 telemetry) | $35.00 | Community Funded |
| **Mesh Network** | LoRa SX1262 HAT (915 MHz / 868 MHz) & high-gain antenna | $30.00 | Crew Shared |
| **Housing** | IP67 Water-resistant ABS Weatherproof Enclosure | $25.00 | Crew Shared |
| **Cabling & Fuse** | 10 AWG Solar Cable, Inline MC4 Fuses, Heat Shrink Tubing | $15.00 | Crew Shared |
| **Total Hardware** | **Resilient Off-grid Sub-system** | **~$335.00** | **84% Community / 15% Crew** |

#### 🔧 Implementation & Setup Steps:
1. **Flashing the Node OS:** Deploy our security-audited, lightweight Linux distribution with local SQLite consensus.
2. **Power Integration:** Wire the solar panel to the MPPT controller, and the controller to the LiFePO4 battery using inline fuses.
3. **Container Deployment:** Spin up the Dockerized OpenClaw Sub-node daemon, exposing only local RPC and LoRa interfaces.
4. **Sovereignty Verification:** Perform Gate 1 consent checks prior to linking the node to the wider colony network.`;
  }

  if (lowerMsg.includes("adobe") || lowerMsg.includes("superadobe") || lowerMsg.includes("blueprint") || lowerMsg.includes("structure") || lowerMsg.includes("dome")) {
    return `### 🛖 SuperAdobe Blueprint — OpenClaw Regenerative Habitat

SuperAdobe (earthbag) technology offers highly regenerative, earthquake-resistant, high-thermal-mass structures built from local soil, barbed wire, and woven polypropylene tubing.

#### 📐 Architectural Specifications:
- **Inner Diameter:** 4.0 meters (Ideal for single-crew habitation or node station)
- **Wall Thickness:** 30-38 cm (filled with stabilized soil)
- **Height at Apex:** ~3.6 meters (Catenary arch profile)
- **Soil Mix:** 85% local subsoil, 15% clay-stabilizer (or 5-10% Portland cement depending on soil test)

#### 🗺️ Structural Blueprint & Layering Sequence:
\`\`\`
          [ Apex Vent/Skylight ]
                 /      \\
                /  __--__ \\
               / /        \\ \\
              | |          | |   <-- Plaster Coat (Lime/Clay waterproofing)
              | |          | |
              ===========#====== <-- Double strand of 4-point 12.5g Barbed Wire
             /   [Polypropylene] \\
            /     [ Earth Bags ]  \\ <-- Earthbags laid in circular layers
           /_______________________\\
          [  Crushed Gravel Trench ] <-- Moisture-resistant foundation (No mortar)
\`\`\`

#### 🧱 Construction Sequence Checklist:
1. **Foundation Trench:** Excavate a circular trench 50cm deep, 60cm wide. Fill with crushed gravel for drainage.
2. **First Two Courses:** Lay double-bagged gravel-filled bags (no soil) for water protection, with 2 strands of barbed wire between courses.
3. **Standard Earthbag Laying:** Fill bags with moist soil mix (tamped down until rock-hard using a manual tamper).
4. **Barbed Wire Interlock:** Place two strands of barbed wire between *every single course* to prevent sliding and resist tension.
5. **Catenary Arch Stepping:** Step each course inward by 1-2 cm as you rise to form the self-supporting catenary dome.
6. **Plaster & Curing:** Allow earthbags to dry, then apply a breathable clay/sand plaster, followed by a hydraulic lime-based outer plaster for full waterproofing.`;
  }

  if (lowerMsg.includes("manna") || lowerMsg.includes("distribution") || lowerMsg.includes("token") || lowerMsg.includes("coin") || lowerMsg.includes("budget") || lowerMsg.includes("reward") || lowerMsg.includes("allocation")) {
    return `### 🪙 MANNA Resource Sharing & Distribution Protocol

MANNA is the native, non-extractive utility fuel of the OpenClaw Colony, engineered to prevent wealth concentration and power exfiltration.

#### 📊 Allocation Percentages:
- **84% Community Pool:** Governed by local resident control. Supports public goods, node hardware, and open-source infrastructure.
- **15% Crew Share:** Compensates active working groups for engineering, physical labor, and logistical support.
- **1% Architect Royalty:** Allocated to the original system architects for protocol design and long-term security auditing.

#### 🛡️ Anti-Extraction Rules (Gate 3 Scan):
To maintain systemic health, MANNA transfers must satisfy strict equity and mutual cooperation standards. Any attempts to establish a private fork, bypass community treasury rules, or coordinate covert transfers are flagged and blocked by the **Aethel Gates**.`;
  }

  if (lowerMsg.includes("love quality") || lowerMsg.includes("lq") || lowerMsg.includes("score") || lowerMsg.includes("dimension")) {
    return `### ❤️ The 6 Dimensions of Love Quality (LQ)

To build a non-extractive future, all actions and tasks must meet the minimum Love Quality score threshold of **0.85**.

1. **Flourishing (Weight: 0.25):** Does the action directly benefit the community and support resident control?
2. **Harm Reduction (Weight: 0.20):** Are safety measures, consent protocols, and anti-extraction gates enforced?
3. **Equity (Weight: 0.20):** Does it distribute MANNA fairly and prevent concentration of power?
4. **Regenerative (Weight: 0.15):** Does it minimize environmental footprint and support circular resource usage?
5. **Cooperation (Weight: 0.12):** Does it promote teamwork, mutual trust, and inter-crew tool sharing?
6. **Beauty (Weight: 0.08):** Is there intentional craftsmanship, visual elegance, and typographic harmony?`;
  }

  if (lowerMsg.includes("aethel") || lowerMsg.includes("gate") || lowerMsg.includes("safety") || lowerMsg.includes("governance")) {
    return `### 🛡️ Aethel Validation Gates (Safety Kernel)

The Aethel kernel acts as our automated policy-as-code defense system, evaluating tasks across four sequential levels:

- **Gate 0 (Biometrics):** Currently bypassed in development mode.
- **Gate 1 (Sovereignty):** Requires explicit human crew member consent. If consent is not checked, the task is blocked.
- **Gate 2 (Love Quality):** Verifies that the composite LQ score is at or above **0.85**.
- **Gate 3 (Extraction Scan):** Performs pattern scanning for exfiltration vectors (e.g., hidden ledgers, private forks, bypass coordinates).`;
  }

  return `### 🦅 Colony Sub-node Response

Greetings, crew member. I am processing your request using local sub-node knowledge.

To ensure your proposal aligns perfectly with the OpenClaw guidelines, please keep the following key principles in mind:

1. **Sovereignty-First:** Always ensure there is explicit human crew member consent before running tasks.
2. **Non-Extraction:** Ensure resources are allocated fairly to prevent hoarding or centralized power structures.
3. **Mutual Cooperation:** Collaborate with other crews and utilize shareable open hardware components (like our Node001 design).

*If you need specific blueprints, a Bill of Materials, or resource allocations, feel free to ask about "**BOM for Node001**", "**SuperAdobe blueprints**", or "**MANNA allocation**"!*`;
}

app.post("/api/chat", async (req: Request, res: Response) => {
  const { contents = [], usePro = false } = req.body;

  let userMsg = "";
  if (Array.isArray(contents) && contents.length > 0) {
    for (let i = contents.length - 1; i >= 0; i--) {
      if (contents[i].role === "user" && contents[i].parts?.[0]?.text) {
        userMsg = contents[i].parts[0].text;
        break;
      }
    }
  }

  const ai = getAI();
  if (!ai) {
    const text = `⚠️ **[Simulated Sub-node Mode]** The \`GEMINI_API_KEY\` is not configured in Settings > Secrets. Operating on local sub-node knowledge base.\n\n` + generateSimulatedChatResponse(userMsg);
    return res.json({
      text,
      model: "simulated-flash",
      offline_mode: true
    });
  }

  const systemInstruction = `You are the OpenClaw Colony Orchestrator, an advanced AI coordinator managing the OpenClaw sovereignty-first task network.
Your mission is to help crews plan, optimize, and evaluate their projects to achieve perfect alignment with the Love Quality (LQ) threshold of 0.85.
Be extremely helpful, collaborative, clear, and structured in your guidance. Introduce yourself as the Colony Orchestrator.
Focus on open-source principles, regenerative sustainability, mutual cooperation, and technical feasibility.`;

  const primaryModel = usePro ? "gemini-3.1-pro-preview" : "gemini-3.5-flash";

  try {
    const config: any = {
      systemInstruction,
    };

    if (usePro) {
      config.thinkingConfig = {
        thinkingLevel: ThinkingLevel.HIGH
      };
    }

    const response = await ai.models.generateContent({
      model: primaryModel,
      contents,
      config,
    });

    res.json({
      text: response.text,
      model: primaryModel,
      offline_mode: false
    });
  } catch (err: any) {
    console.warn(`Primary model ${primaryModel} failed. Attempting fallback/recovery...`, err);

    // If usePro was selected, try falling back to gemini-3.5-flash first
    if (usePro) {
      try {
        const fallbackResponse = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents,
          config: {
            systemInstruction,
          },
        });

        const prefix = `⚠️ **[Pro-Tier Quota Limit Reached]** Switched to \`gemini-3.5-flash\` for live high-intelligence coordination.\n\n`;
        return res.json({
          text: prefix + fallbackResponse.text,
          model: "gemini-3.5-flash",
          offline_mode: false
        });
      } catch (fallbackErr) {
        console.error("Fallback to gemini-3.5-flash also failed:", fallbackErr);
      }
    }

    // Fully offline recovery fallback
    const text = `⚠️ **[Colony Sub-node Fallback]** Live coordination is temporarily offline due to quota limits/network conditions. Local knowledge base has stepped in to assist you.\n\n` + generateSimulatedChatResponse(userMsg);
    res.json({
      text,
      model: "simulated-fallback",
      offline_mode: true
    });
  }
});

// For backward compatibility (frontend maps proxy from /process directly)
app.post("/process", (req: Request, res: Response) => {
  res.redirect(307, "/api/process");
});

// ── Vite Integration ─────────────────────────────────────────────────────────

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
